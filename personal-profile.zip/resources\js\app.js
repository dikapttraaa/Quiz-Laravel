import '../css/app.css';
import Alpine from 'alpinejs';

import './cursor-trail.js';
import './cursor-follower.js';
import './scroll-animation.js';
import './parallax.js';
import './magnetic-button.js';
import './gallery.js';

window.Alpine = Alpine;
Alpine.start();

const navToggle = document.querySelector('[data-nav-toggle]');
const navMenu = document.querySelector('[data-nav-menu]');

if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
        const isOpen = navMenu.classList.toggle('is-open');
        navToggle.setAttribute('aria-expanded', String(isOpen));
        navMenu.setAttribute('aria-hidden', String(!isOpen));
    });

    navMenu.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('is-open');
            navToggle.setAttribute('aria-expanded', 'false');
            navMenu.setAttribute('aria-hidden', 'true');
        });
    });
}

const currentPath = window.location.pathname;
const navLinks = document.querySelectorAll('[data-nav-link]');

navLinks.forEach((link) => {
    const href = link.getAttribute('href');
    if (href === currentPath || (currentPath === '/' && href === '/')) {
        link.classList.add('text-cyan-300', 'border-cyan-400/70');
        link.classList.remove('text-slate-200');
    }
});
