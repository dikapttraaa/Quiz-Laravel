<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;

/*
|--------------------------------------------------------------------------
| Web Routes - Personal Profile Interactive Futuristic
|--------------------------------------------------------------------------
| Semua rute menggunakan Laravel Named Routes sesuai ketentuan:
| 1. 'welcome' -> Halaman Utama / Hero & Interactive Experience
| 2. 'about'   -> Halaman Data Diri & Profil Lengkap
| 3. 'gallery' -> Halaman Galeri Portofolio & Lightbox Interaktif
*/

Route::get('/', [ProfileController::class, 'welcome'])->name('welcome');
Route::get('/about', [ProfileController::class, 'about'])->name('about');
Route::get('/gallery', [ProfileController::class, 'gallery'])->name('gallery');
