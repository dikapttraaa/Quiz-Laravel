<footer class="relative z-10 border-t border-white/10 bg-slate-950/80">
    <div class="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-4 py-8 text-sm text-slate-300 sm:px-6 lg:flex-row lg:px-8">
        <div>
            <p>© <?php echo e(date('Y')); ?> <?php echo e($profile['full_name'] ?? 'Dikaptra'); ?>.</p>
        </div>

        <div class="flex items-center gap-3 text-slate-200">
            <a href="https://www.instagram.com/dikapttra_?mdxt=MWxzdXpycGU1eXl6ZA==" aria-label="Instagram" class="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 transition hover:border-cyan-400/40 hover:text-cyan-300">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
                    <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
                    <circle cx="12" cy="12" r="4" />
                    <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
                </svg>
            </a>
            <a href="https://github.com/dikapttraaa" aria-label="GitHub" class="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 transition hover:border-cyan-400/40 hover:text-cyan-300">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 .5C5.7.5.7 5.5.7 11.8c0 4.9 3.2 9 7.6 10.5.6.1.8-.3.8-.6v-2.2c-3.1.7-3.7-1.3-3.7-1.3-.5-1.3-1.2-1.7-1.2-1.7-1-.7.1-.7.1-.7 1.1.1 1.7 1.1 1.7 1.1 1 .1 2.1-.7 2.7-1.3.2-.5.5-1 .8-1.3-2.4-.3-5-1.2-5-5.4 0-1.2.4-2.1 1.1-2.9-.1-.3-.5-1.4.1-2.9 0 0 .9-.3 3 .1 1.2-.3 2.4-.5 3.7-.5s2.5.2 3.7.5c2.1-.4 3-.1 3-.1.7 1.5.2 2.6.1 2.9.7.8 1.1 1.7 1.1 2.9 0 4.2-2.6 5.1-5 5.4.5.4.9 1.2.9 2.4v3.2c0 .3.2.7.8.6 4.4-1.5 7.6-5.6 7.6-10.5C23.3 5.5 18.3.5 12 .5Z"/>
                </svg>
            </a>
            <a href="https://linkedin.com" aria-label="LinkedIn" class="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 transition hover:border-cyan-400/40 hover:text-cyan-300">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M6.94 8.5A1.5 1.5 0 1 1 6.94 5.5a1.5 1.5 0 0 1 0 3Zm-1.5 1.2h3V18h-3V9.7Zm5.2 0h2.9v1.1h.1c.4-.8 1.4-1.7 2.9-1.7 3.1 0 3.7 2 3.7 4.7V18h-3v-16.8h-3V18h-3V9.7Z"/>
                </svg>
            </a>
        </div>

        <p class="font-medium text-cyan-200">Made with AI</p>
    </div>
</footer>
<?php /**PATH C:\Users\LENOVO\Downloads\Quiz-Laravel\personal-profile\resources\views/components/footer.blade.php ENDPATH**/ ?>