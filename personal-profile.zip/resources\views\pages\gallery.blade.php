@extends('layouts.app')

@section('content')
<section class="px-4 py-20 sm:px-6 lg:px-8">
    <div class="mx-auto max-w-7xl">
        <div class="reveal mb-16 text-center">
            <p class="mb-4 text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300">Galeri</p>
            <h2 class="section-title mx-auto text-white">Creative Showcase</h2>
        </div>

        <div id="gallery-grid" class="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
            @foreach(range(1, 9) as $number)
                @if($number === 7)
                    <button
                        type="button"
                        data-gallery-toggle
                        aria-expanded="false"
                        aria-controls="gallery-grid"
                        class="reveal sm:col-span-2 xl:col-span-3 inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 font-semibold text-cyan-200 transition hover:border-cyan-400/40 hover:bg-cyan-400/10"
                    >
                        Other
                        <span aria-hidden="true">↓</span>
                    </button>
                @endif

                @php($videoSource = '/images/gallery/' . $number . '.mp4')
                <article @if($number > 6) data-gallery-extra-item class="hidden reveal gallery-item group relative overflow-hidden rounded-[1.75rem] border border-white/10 bg-slate-900/60" @else class="reveal gallery-item group relative overflow-hidden rounded-[1.75rem] border border-white/10 bg-slate-900/60" @endif>
                    <button
                        type="button"
                        data-gallery-open
                        data-video="{{ $videoSource }}"
                        data-title="Video {{ $number }}"
                        data-description="Video {{ $number }} dari galeri."
                        class="block w-full text-left"
                    >
                        <div class="relative overflow-hidden">
                            <video
                                @if($number <= 6)
                                    src="{{ $videoSource }}"
                                    autoplay
                                @else
                                    data-video-src="{{ $videoSource }}"
                                @endif
                                muted
                                loop
                                playsinline
                                preload="{{ $number <= 6 ? 'metadata' : 'none' }}"
                                aria-label="Video {{ $number }}"
                                class="h-72 w-full object-cover"
                            ></video>
                            <div class="pointer-events-none absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-80"></div>
                        </div>
                        <div class="p-5">
                            <h3 class="text-xl font-semibold text-white">Video {{ $number }}</h3>
                            <p class="mt-2 text-sm leading-relaxed text-slate-300">Klik untuk menonton video.</p>
                        </div>
                    </button>
                </article>
            @endforeach
        </div>

    </div>
</section>

<div id="gallery-modal" role="dialog" aria-modal="true" aria-labelledby="gallery-modal-title" class="fixed inset-0 z-50 hidden flex items-center justify-center overflow-y-auto bg-slate-950/80 p-4 backdrop-blur-sm">
    <div class="relative flex max-h-[92vh] w-fit max-w-[calc(100vw-2rem)] flex-col overflow-y-auto rounded-[2rem] border border-white/10 bg-slate-900 p-4 shadow-[0_35px_90px_rgba(15,23,42,0.9)]">
        <button id="gallery-modal-close" type="button" aria-label="Tutup galeri" class="absolute right-5 top-5 z-10 flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-slate-950/80 text-lg text-white hover:border-cyan-400/50 hover:text-cyan-200">×</button>
        <video id="gallery-modal-video" controls loop playsinline class="block max-h-[70vh] w-auto max-w-full rounded-2xl object-contain"></video>
        <p id="gallery-modal-playback-error" role="status" class="hidden px-4 pt-3 text-sm text-amber-200">Video tidak dapat diputar otomatis. Tekan tombol putar pada video.</p>
        <div class="p-4">
            <h3 id="gallery-modal-title" class="text-2xl font-bold text-white"></h3>
            <p id="gallery-modal-description" class="mt-2 text-slate-300"></p>
        </div>
    </div>
</div>
@endsection
