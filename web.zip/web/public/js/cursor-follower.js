/**
 * ============================================================================
 * INTERACTIVE CURSOR FOLLOWER WITH FLUID INERTIA & MASS
 * Inspired by Google Antigravity IDE
 * ============================================================================
 * Menggunakan linear interpolation (lerp) dan requestAnimationFrame
 * untuk menghasilkan pergerakan kursor yang halus, memiliki massa, inersia,
 * dan efek glowing dinamis saat berinteraksi dengan elemen UI.
 */

(function () {
    'use strict';

    // 1. Deteksi apakah perangkat mendukung pointer presisi (Mouse / Trackpad)
    const isFinePointer = window.matchMedia('(pointer: fine) and (hover: hover)').matches;
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!isFinePointer || prefersReducedMotion) {
        return; // Jangan jalankan di perangkat touchscreen atau pengguna reduced-motion
    }

    const dot = document.getElementById('cursor-dot');
    const glow = document.getElementById('cursor-glow');

    if (!dot || !glow) return;

    // Koordinat kursor target (posisi aktual mouse)
    let mouseX = -100;
    let mouseY = -100;

    // Koordinat dot (mengikuti mouse secara instan / semi-instan)
    let dotX = -100;
    let dotY = -100;

    // Koordinat glow orb (mengikuti mouse dengan inersia, easing & lerp)
    let glowX = -100;
    let glowY = -100;

    // Faktor interpolasi (Lerp Factor: semakin kecil semakin terasa memiliki massa/delay)
    const DOT_LERP = 0.85;
    const GLOW_LERP = 0.14;

    let isVisible = false;
    let isHovering = false;
    let isClicking = false;

    // Utility Linear Interpolation
    function lerp(start, end, factor) {
        return start + (end - start) * factor;
    }

    // Event Listener Mouse Movement
    window.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;

        if (!isVisible) {
            isVisible = true;
            dotX = mouseX;
            dotY = mouseY;
            glowX = mouseX;
            glowY = mouseY;
            dot.style.opacity = '1';
            glow.style.opacity = '1';
        }
    }, { passive: true });

    // Sembunyikan kursor saat mouse keluar dari window
    document.addEventListener('mouseleave', () => {
        isVisible = false;
        dot.style.opacity = '0';
        glow.style.opacity = '0';
    });

    document.addEventListener('mouseenter', () => {
        isVisible = true;
        dot.style.opacity = '1';
        glow.style.opacity = '1';
    });

    // Mousedown & Mouseup Interaction (Scaling effect)
    window.addEventListener('mousedown', () => {
        isClicking = true;
        document.body.classList.add('cursor-active');
    });

    window.addEventListener('mouseup', () => {
        isClicking = false;
        document.body.classList.remove('cursor-active');
    });

    // Deteksi hover pada elemen interaktif (Button, Links, Cards, Input)
    function setupInteractiveListeners() {
        const interactiveElements = document.querySelectorAll(
            'a, button, input, textarea, select, .magnetic-btn, .tilt-card, [data-gallery-item]'
        );

        interactiveElements.forEach((el) => {
            el.addEventListener('mouseenter', () => {
                isHovering = true;
                document.body.classList.add('cursor-hover');
            });

            el.addEventListener('mouseleave', () => {
                isHovering = false;
                document.body.classList.remove('cursor-hover');
            });
        });
    }

    setupInteractiveListeners();

    // Re-check elemen baru jika DOM bertambah
    const observer = new MutationObserver(() => {
        setupInteractiveListeners();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Animasi Loop menggunakan requestAnimationFrame (60 FPS Hardware-Accelerated)
    function animateCursor() {
        if (isVisible) {
            // Interpolasi koordinat dot
            dotX = lerp(dotX, mouseX, DOT_LERP);
            dotY = lerp(dotY, mouseY, DOT_LERP);

            // Interpolasi koordinat glow orb (dengan inersia lembut)
            glowX = lerp(glowX, mouseX, GLOW_LERP);
            glowY = lerp(glowY, mouseY, GLOW_LERP);

            // Gunakan translate3d untuk akselerasi GPU
            dot.style.transform = `translate3d(${dotX}px, ${dotY}px, 0) translate(-50%, -50%)`;
            glow.style.transform = `translate3d(${glowX}px, ${glowY}px, 0) translate(-50%, -50%)`;
        }

        requestAnimationFrame(animateCursor);
    }

    requestAnimationFrame(animateCursor);
})();
