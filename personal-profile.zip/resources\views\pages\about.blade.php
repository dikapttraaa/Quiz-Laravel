@extends('layouts.app')

@section('content')
<section class="px-4 py-20 sm:px-6 lg:px-8">
    <div class="mx-auto max-w-7xl">
        <div class="reveal mb-14 text-center">
            <p class="mb-4 text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300">Profil Saya</p>
            <h2 class="section-title mx-auto text-white">Personal Profile</h2>
        </div>

        <div class="grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
            <div class="reveal card-tilt glass-panel rounded-[2rem] p-6">
                <div class="overflow-hidden rounded-[1.5rem] border border-white/10 bg-gradient-to-br from-violet-500/10 via-slate-900 to-cyan-500/10 p-5">
                    <img src="/images/profile.svg" alt="Profile image" class="h-[420px] w-full rounded-[1.2rem] object-cover shadow-[0_0_30px_rgba(56,189,248,0.15)]" />
                </div>
            </div>

            <div class="reveal space-y-8">
                <div class="glass-panel card-tilt rounded-[2rem] p-6 md:p-8">
                    <p class="text-lg leading-relaxed text-slate-300">
                        {{ $profile['description'] }}
                    </p>
                    <div class="mt-6 flex flex-wrap gap-3">
                        @foreach($profile['skills'] as $skill)
                            <span class="rounded-full border border-cyan-400/30 bg-cyan-500/10 px-3 py-1.5 text-sm text-cyan-100">{{ $skill }}</span>
                        @endforeach
                    </div>
                </div>

                <div class="grid gap-6 md:grid-cols-2">
                    @foreach($infos as $info)
                        <div class="reveal glass-panel card-tilt rounded-[1.5rem] p-5">
                            <p class="text-xs uppercase tracking-[0.25em] text-slate-400">{{ $info['label'] }}</p>
                            <p class="mt-3 text-base font-semibold text-white">{{ $info['value'] }}</p>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <div class="mt-20 grid gap-8 lg:grid-cols-2">
            <div class="reveal glass-panel rounded-[2rem] p-6 md:p-8">
                <h3 class="mb-6 text-2xl font-bold text-white">Education Journey</h3>
                <div class="space-y-5">
                    @foreach($education as $item)
                        <div class="rounded-2xl border border-white/10 bg-white/5 p-5">
                            <p class="text-xs uppercase tracking-[0.28em] text-cyan-300">{{ $item['period'] }}</p>
                            <h4 class="mt-3 text-xl font-semibold text-white">{{ $item['title'] }}</h4>
                            <p class="mt-3 text-slate-300">{{ $item['detail'] }}</p>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="reveal glass-panel rounded-[2rem] p-6 md:p-8">
                <h3 class="mb-6 text-2xl font-bold text-white">Hobbies & Passion</h3>
                <div class="flex flex-wrap gap-3">
                    @foreach($profile['hobbies'] as $hobby)
                        <span class="rounded-full border border-violet-400/30 bg-violet-500/10 px-4 py-2 text-sm text-violet-100">{{ $hobby }}</span>
                    @endforeach
                </div>

                <div class="mt-10 rounded-2xl border border-cyan-400/20 bg-cyan-500/5 p-5">
                    <p class="text-xs uppercase tracking-[0.28em] text-cyan-300">Cita-Cita</p>
                    <p class="mt-3 text-lg font-medium text-white">{{ $profile['vision'] }}</p>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
