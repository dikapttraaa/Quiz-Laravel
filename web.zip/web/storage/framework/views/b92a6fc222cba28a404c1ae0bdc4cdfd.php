<?php $__env->startSection('title', 'Data Diri & Profil Lengkap — ' . $profile['name']); ?>

<?php $__env->startSection('content'); ?>
<div class="relative py-12 sm:py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">

    <div class="max-w-7xl mx-auto space-y-24 sm:space-y-32">

        <!-- ========================================================================= -->
        <!-- SECTION 1: HEADER & PROFILE HERO OVERVIEW                                 -->
        <!-- ========================================================================= -->
        <section class="relative reveal-on-scroll">
            
            <!-- Page Title Breadcrumb -->
            <div class="text-center max-w-3xl mx-auto mb-14 space-y-4">
                <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
                    <i data-lucide="terminal" class="w-3.5 h-3.5"></i>
                    BIOMETRIC PROFILE // IDENTITY DECK
                </div>
                <h1 class="text-4xl sm:text-6xl font-display font-extrabold text-white tracking-tight">
                    Data Diri & Profil Lengkap
                </h1>
                <p class="text-slate-400 text-base sm:text-lg leading-relaxed">
                    Eksplorasi identitas personal, latar belakang akademis, keahlian rekayasa perangkat lunak, hobi kreatif, serta visi masa depan saya.
                </p>
            </div>

            <!-- Main Identity Card (3D Tilt & Glassmorphism) -->
            <div class="relative rounded-3xl p-6 sm:p-10 lg:p-12 bg-gradient-to-b from-dark-850/90 via-dark-900/90 to-dark-950/95 border border-cyan-500/30 backdrop-blur-2xl shadow-[0_20px_60px_rgba(0,0,0,0.5)] tilt-card group" data-tilt-max="7">
                
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
                    
                    <!-- Left: Interactive Profile Avatar with Glowing Halo & Status -->
                    <div class="lg:col-span-4 flex flex-col items-center text-center space-y-5">
                        <div class="relative">
                            <!-- Animated Cyber Halo Ring -->
                            <div class="absolute -inset-3 rounded-full bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 opacity-60 blur-lg group-hover:opacity-100 transition-opacity duration-500"></div>
                            
                            <!-- Profile Photo (Easily replaceable via $profile['photo']) -->
                            <div class="relative w-44 h-44 sm:w-52 sm:h-52 rounded-full overflow-hidden border-2 border-cyan-400/80 bg-dark-900 p-1.5 shadow-2xl">
                                <img src="<?php echo e(asset($profile['photo'])); ?>" 
                                     alt="<?php echo e($profile['name']); ?>" 
                                     class="w-full h-full object-cover rounded-full transition-transform duration-700 group-hover:scale-105">
                            </div>

                            <!-- Live Status Indicator Pill -->
                            <div class="absolute bottom-2 right-2 px-3 py-1 rounded-full bg-dark-950/90 border border-emerald-400/50 flex items-center gap-2 text-xs font-mono text-emerald-400 shadow-lg">
                                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                <span>Active</span>
                            </div>
                        </div>

                        <div>
                            <h2 class="text-2xl font-display font-bold text-white">
                                <?php echo e($profile['name']); ?>

                            </h2>
                            <p class="text-sm font-mono text-cyan-400 mt-1">
                                <?php echo e($profile['title']); ?>

                            </p>
                            <span class="inline-block mt-2 px-3 py-1 rounded-full text-xs font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                                <?php echo e($profile['status']); ?>

                            </span>
                        </div>

                        <!-- Quick Action Button to Copy Email -->
                        <button id="copy-email-btn" 
                                data-email="<?php echo e($profile['email']); ?>" 
                                class="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-dark-750 hover:bg-cyan-500/10 text-xs font-mono text-cyan-300 border border-white/[0.1] hover:border-cyan-400/50 transition-all flex items-center justify-center gap-2 magnetic-btn">
                            <i data-lucide="copy" class="w-3.5 h-3.5"></i>
                            <span>Salin Email Resmi</span>
                        </button>
                    </div>

                    <!-- Right: Bio Description & Aspirations / Cita-cita -->
                    <div class="lg:col-span-8 space-y-6 lg:border-l lg:border-white/[0.08] lg:pl-10">
                        
                        <!-- Deskripsi Singkat Diri Sendiri -->
                        <div class="space-y-3">
                            <h3 class="text-xs font-mono uppercase tracking-widest text-cyan-400 flex items-center gap-2">
                                <i data-lucide="file-text" class="w-4 h-4"></i>
                                Deskripsi Diri & Filosofi Rekayasa
                            </h3>
                            <p class="text-slate-300 text-base sm:text-lg leading-relaxed">
                                <?php echo e($profile['bio_full']); ?>

                            </p>
                        </div>

                        <!-- Cita-Cita & Visi Masa Depan -->
                        <div class="space-y-3 pt-3 border-t border-white/[0.08]">
                            <h3 class="text-xs font-mono uppercase tracking-widest text-purple-400 flex items-center gap-2">
                                <i data-lucide="target" class="w-4 h-4"></i>
                                Cita-Cita & Ambisi Masa Depan
                            </h3>
                            <div class="space-y-2.5">
                                <?php $__currentLoopData = $profile['aspirations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $aspiration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-start gap-3 p-3.5 rounded-xl bg-purple-500/5 border border-purple-500/20 text-sm text-slate-200">
                                        <div class="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0 mt-0.5 font-mono text-xs font-bold">
                                            0<?php echo e($idx + 1); ?>

                                        </div>
                                        <p class="leading-relaxed">
                                            <?php echo e($aspiration); ?>

                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </section>

        <!-- ========================================================================= -->
        <!-- SECTION 2: DETAIL INFORMASI DIRI (LOOPING @foreach BLADE)                -->
        <!-- ========================================================================= -->
        <section class="relative reveal-on-scroll">
            <div class="mb-10 text-center sm:text-left space-y-2">
                <div class="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-cyan-400">
                    <i data-lucide="database" class="w-4 h-4"></i>
                    Informasi Personal Spesifik
                </div>
                <h2 class="text-2xl sm:text-4xl font-display font-bold text-white">
                    Data Pribadi Terstruktur
                </h2>
                <p class="text-sm text-slate-400">
                    Data berikut dikirim dari <code class="text-cyan-300 font-mono text-xs">ProfileController.php</code> dan dirender menggunakan looping directive <code class="text-cyan-300 font-mono text-xs">@foreach</code>.
                </p>
            </div>

            <!-- Responsive Cards Grid Generated via @foreach Loop -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <?php $__currentLoopData = $personalDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-5 rounded-2xl bg-dark-850/60 border border-white/[0.08] hover:border-cyan-500/40 backdrop-blur-md transition-all duration-300 group tilt-card shadow-sm hover:shadow-[0_0_25px_rgba(6,182,212,0.15)]" data-tilt-max="10">
                        <div class="flex items-start justify-between mb-3">
                            <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center group-hover:scale-110 group-hover:bg-cyan-500/20 transition-all">
                                <i data-lucide="<?php echo e($detail['icon']); ?>" class="w-5 h-5"></i>
                            </div>
                            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-white/[0.04] text-slate-400 border border-white/[0.06]">
                                <?php echo e($detail['badge']); ?>

                            </span>
                        </div>
                        <span class="text-xs font-mono text-slate-400 block mb-1">
                            <?php echo e($detail['label']); ?>

                        </span>
                        <div class="text-base font-semibold text-white group-hover:text-cyan-300 transition-colors break-words">
                            <?php echo e($detail['value']); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <!-- ========================================================================= -->
        <!-- SECTION 3: RIWAYAT PENDIDIKAN (EDUCATION TIMELINE LOOPING @foreach)      -->
        <!-- ========================================================================= -->
        <section class="relative reveal-on-scroll">
            <div class="mb-12 text-center sm:text-left space-y-2">
                <div class="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-cyan-400">
                    <i data-lucide="graduation-cap" class="w-4 h-4"></i>
                    Latar Belakang Akademis
                </div>
                <h2 class="text-2xl sm:text-4xl font-display font-bold text-white">
                    Riwayat Pendidikan
                </h2>
                <p class="text-sm text-slate-400">
                    Jejak pembelajaran formal dan riset akademik yang ditempuh untuk mengasah kompetensi komputasi.
                </p>
            </div>

            <!-- Timeline Stacked Cards (Looping Blade) -->
            <div class="space-y-8 relative before:absolute before:inset-0 before:left-5 sm:before:left-8 before:w-0.5 before:bg-gradient-to-b before:from-cyan-500/50 before:via-purple-500/30 before:to-transparent">
                <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative pl-12 sm:pl-20 group">
                        
                        <!-- Timeline Node Dot with Glow -->
                        <div class="absolute left-3 sm:left-6 -translate-x-1/2 top-7 w-5 h-5 rounded-full bg-dark-950 border-2 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.6)] flex items-center justify-center group-hover:scale-125 transition-transform">
                            <div class="w-2 h-2 rounded-full bg-cyan-400"></div>
                        </div>

                        <!-- Timeline Content Card (3D Tilt) -->
                        <div class="rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-dark-850/80 to-dark-900/90 border border-white/[0.08] hover:border-cyan-400/50 backdrop-blur-xl shadow-lg transition-all duration-300 tilt-card" data-tilt-max="8">
                            
                            <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
                                <span class="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                                    <?php echo e($edu['period']); ?>

                                </span>
                                <span class="text-xs font-mono text-purple-400 bg-purple-500/10 px-3 py-1 rounded-full border border-purple-500/20">
                                    <?php echo e($edu['gpa']); ?>

                                </span>
                            </div>

                            <h3 class="text-xl sm:text-2xl font-display font-bold text-white group-hover:text-cyan-300 transition-colors">
                                <?php echo e($edu['institution']); ?>

                            </h3>
                            <p class="text-base font-medium text-cyan-400 mt-1">
                                <?php echo e($edu['degree']); ?>

                            </p>
                            <p class="text-xs font-mono text-slate-400 mt-1">
                                <?php echo e($edu['thesis']); ?>

                            </p>

                            <p class="text-sm text-slate-300 mt-4 leading-relaxed">
                                <?php echo e($edu['description']); ?>

                            </p>

                            <!-- Academic Achievements Badges -->
                            <div class="mt-5 pt-4 border-t border-white/[0.06] flex flex-wrap gap-2">
                                <?php $__currentLoopData = $edu['achievements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achieve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-mono bg-white/[0.03] text-slate-300 border border-white/[0.08]">
                                        <i data-lucide="check-circle" class="w-3.5 h-3.5 text-cyan-400"></i>
                                        <?php echo e($achieve); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <!-- ========================================================================= -->
        <!-- SECTION 4: KEAHLIAN TEKNIS (SKILLS MATRIX LOOPING @foreach)              -->
        <!-- ========================================================================= -->
        <section class="relative reveal-on-scroll">
            <div class="mb-12 text-center sm:text-left space-y-2">
                <div class="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-cyan-400">
                    <i data-lucide="cpu" class="w-4 h-4"></i>
                    Matriks Kemampuan
                </div>
                <h2 class="text-2xl sm:text-4xl font-display font-bold text-white">
                    Keahlian & Penguasaan Teknologi
                </h2>
                <p class="text-sm text-slate-400">
                    Spektrum kompetensi teknis dari backend architecture, rekayasa visual interaktif, hingga cloud infrastructure.
                </p>
            </div>

            <!-- Categories Grid via @foreach -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $skillCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-3xl p-6 sm:p-7 bg-gradient-to-b from-dark-850/80 to-dark-900/90 border border-white/[0.08] hover:border-cyan-400/40 backdrop-blur-xl shadow-lg transition-all duration-300 tilt-card space-y-6" data-tilt-max="9">
                        
                        <!-- Category Header -->
                        <div class="flex items-center gap-3 pb-4 border-b border-white/[0.08]">
                            <div class="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center">
                                <i data-lucide="<?php echo e($cat['icon']); ?>" class="w-5 h-5"></i>
                            </div>
                            <div>
                                <h3 class="font-display font-bold text-lg text-white">
                                    <?php echo e($cat['category']); ?>

                                </h3>
                                <p class="text-xs text-slate-400">
                                    <?php echo e($cat['description']); ?>

                                </p>
                            </div>
                        </div>

                        <!-- Skill Items Looping -->
                        <div class="space-y-4">
                            <?php $__currentLoopData = $cat['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="space-y-2">
                                    <div class="flex items-center justify-between text-xs font-mono">
                                        <span class="text-slate-200 font-medium"><?php echo e($skill['name']); ?></span>
                                        <span class="text-cyan-400 font-semibold"><?php echo e($skill['level']); ?>%</span>
                                    </div>
                                    <!-- Progress Bar Container -->
                                    <div class="w-full h-2 rounded-full bg-dark-950 overflow-hidden border border-white/[0.06] p-0.5">
                                        <div class="h-full rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-1000 shadow-[0_0_10px_rgba(6,182,212,0.5)]" 
                                             style="width: <?php echo e($skill['level']); ?>%"></div>
                                    </div>
                                    <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
                                        <span><?php echo e($skill['exp']); ?></span>
                                        <span class="text-purple-300"><?php echo e($skill['highlight']); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <!-- ========================================================================= -->
        <!-- SECTION 5: HOBI & MINAT KREATIF (HOBBIES LOOPING @foreach)               -->
        <!-- ========================================================================= -->
        <section class="relative reveal-on-scroll">
            <div class="mb-12 text-center sm:text-left space-y-2">
                <div class="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-cyan-400">
                    <i data-lucide="gamepad-2" class="w-4 h-4"></i>
                    Aktivitas & Minat Personal
                </div>
                <h2 class="text-2xl sm:text-4xl font-display font-bold text-white">
                    Hobi & Eksplorasi Kreatif
                </h2>
                <p class="text-sm text-slate-400">
                    Keseimbangan antara logika rekayasa perangkat lunak, eksplorasi estetika antarmuka, dan kreativitas audio.
                </p>
            </div>

            <!-- Hobby Cards Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-3xl p-6 bg-gradient-to-b from-dark-850/80 to-dark-900/90 border border-white/[0.08] hover:border-cyan-400/50 backdrop-blur-xl shadow-md transition-all duration-500 tilt-card group" data-tilt-max="12">
                        
                        <div class="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-cyan-500/20 transition-all">
                            <i data-lucide="<?php echo e($hobby['icon']); ?>" class="w-6 h-6"></i>
                        </div>

                        <h3 class="font-display font-bold text-base sm:text-lg text-white group-hover:text-cyan-300 transition-colors mb-2">
                            <?php echo e($hobby['title']); ?>

                        </h3>

                        <p class="text-xs sm:text-sm text-slate-400 leading-relaxed mb-4">
                            <?php echo e($hobby['desc']); ?>

                        </p>

                        <!-- Hobby Tags -->
                        <div class="flex flex-wrap gap-1.5 pt-3 border-t border-white/[0.06]">
                            <?php $__currentLoopData = $hobby['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-white/[0.03] text-slate-300 border border-white/[0.06]">
                                    #<?php echo e($tag); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <!-- ========================================================================= -->
        <!-- SECTION 6: DIRECT CONTACT & COLLABORATION                                 -->
        <!-- ========================================================================= -->
        <section id="contact" class="relative rounded-3xl p-8 sm:p-14 bg-gradient-to-r from-dark-850/90 via-dark-900/90 to-dark-950/95 border border-cyan-500/30 backdrop-blur-2xl shadow-2xl reveal-on-scroll">
            <div class="max-w-3xl mx-auto text-center space-y-6">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-mono text-cyan-300">
                    <i data-lucide="mail" class="w-3.5 h-3.5"></i>
                    HUBUNGI SAYA
                </div>

                <h2 class="text-3xl sm:text-5xl font-display font-extrabold text-white tracking-tight">
                    Tertarik Berkolaborasi atau Diskusi Proyek?
                </h2>

                <p class="text-slate-300 text-sm sm:text-base leading-relaxed">
                    Saya selalu terbuka untuk berdiskusi mengenai arsitektur sistem skala enterprise, pembuatan antarmuka web interaktif futuristik, maupun peluang kolaborasi profesional.
                </p>

                <div class="flex flex-wrap items-center justify-center gap-4 pt-2">
                    <a href="mailto:<?php echo e($profile['email']); ?>" 
                       class="px-8 py-4 rounded-xl text-sm font-semibold tracking-wide text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-[0_0_25px_rgba(6,182,212,0.4)] transition-all duration-300 magnetic-btn flex items-center gap-2">
                        <i data-lucide="send" class="w-4 h-4"></i>
                        Kirim Pesan Email
                    </a>
                    <a href="<?php echo e(route('gallery')); ?>" 
                       class="px-8 py-4 rounded-xl text-sm font-semibold tracking-wide text-slate-200 bg-dark-750 hover:bg-dark-700 border border-white/[0.1] hover:border-cyan-400/50 transition-all duration-300 magnetic-btn flex items-center gap-2">
                        <i data-lucide="images" class="w-4 h-4 text-cyan-400"></i>
                        Jelajahi Galeri Proyek
                    </a>
                </div>
            </div>
        </section>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dikap\OneDrive\Dokumen\web\resources\views/pages/about.blade.php ENDPATH**/ ?>