@extends('layouts.app')

@section('title', $name . ' — Futuristic Personal Profile & System Architect')

@section('content')
<div class="relative overflow-hidden">

    <!-- ========================================================================= -->
    <!-- HERO SECTION (INTERACTIVE FUTURISTIC ANTIGRAVITY SHOWCASE)                 -->
    <!-- ========================================================================= -->
    <section class="relative min-h-[92vh] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        
        <!-- Background Radial Halo & Vector Lines -->
        <div class="absolute inset-0 flex items-center justify-center pointer-events-none" aria-hidden="true">
            <div class="w-[800px] h-[800px] rounded-full bg-gradient-to-b from-cyan-500/10 via-purple-600/10 to-transparent blur-3xl opacity-60 animate-pulse-glow"></div>
            <!-- Central Cyber Grid Ring -->
            <div class="absolute w-[500px] h-[500px] sm:w-[650px] sm:h-[650px] rounded-full border border-cyan-500/15 border-dashed animate-spin-slow"></div>
            <div class="absolute w-[360px] h-[360px] sm:w-[480px] sm:h-[480px] rounded-full border border-purple-500/15 animate-spin-reverse"></div>
        </div>

        <div class="max-w-7xl mx-auto w-full relative z-10">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
                
                <!-- Left Column: Typography, Dynamic Greeting, Name & CTA -->
                <div class="lg:col-span-7 text-center lg:text-left space-y-7 reveal-on-scroll">
                    
                    <!-- System Status Badge -->
                    <div class="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-dark-850/80 border border-cyan-500/30 backdrop-blur-md shadow-[0_0_15px_rgba(6,182,212,0.15)] text-xs font-mono">
                        <span class="relative flex h-2 w-2">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
                        </span>
                        <span class="text-cyan-300 font-semibold tracking-wide">SYSTEM READY</span>
                        <span class="text-slate-500">|</span>
                        <span class="text-slate-300">Antigravity Interactive Engine</span>
                    </div>

                    <!-- Main Welcome Heading & DYNAMIC NAME (DIKIRIM DARI CONTROLLER) -->
                    <div class="space-y-3">
                        <p class="text-sm sm:text-base font-mono uppercase tracking-[0.25em] text-cyan-400 font-medium">
                            // SELAMAT DATANG DI RUANG DIGITAL
                        </p>
                        
                        <!-- Variabel Nama yang dikirim dari ProfileController: {{ $name }} -->
                        <h1 class="text-4xl sm:text-6xl lg:text-7xl font-display font-extrabold tracking-tight text-white leading-[1.1]">
                            Halo, Saya <br class="hidden sm:inline">
                            <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 relative inline-block">
                                {{ $name }}
                                <!-- Underline Glow Accent -->
                                <span class="absolute left-0 bottom-1 w-full h-[3px] bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full blur-[1px]"></span>
                            </span>
                        </h1>

                        <!-- Dynamic Role & Tagline -->
                        <p class="text-lg sm:text-xl font-medium text-slate-300 font-display">
                            {{ $role }}
                        </p>
                    </div>

                    <!-- Brief Description / Tagline Paragraph -->
                    <p class="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-sans">
                        {{ $bioShort }}
                    </p>

                    <!-- Interactive Call-To-Action Buttons (with Magnetic Physics) -->
                    <div class="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
                        
                        <!-- Button 1: Lihat Profil Saya (Named route: 'about') -->
                        <a href="{{ route('about') }}" 
                           class="relative group px-7 py-4 rounded-xl text-sm font-semibold tracking-wide text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-[0_0_25px_rgba(6,182,212,0.4)] hover:shadow-[0_0_35px_rgba(6,182,212,0.7)] transition-all duration-300 magnetic-btn flex items-center gap-3">
                            <span class="relative z-10 flex items-center gap-2">
                                <i data-lucide="user" class="w-4 h-4"></i>
                                Lihat Profil Saya
                            </span>
                            <i data-lucide="arrow-right" class="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1"></i>
                        </a>

                        <!-- Button 2: Jelajahi Galeri (Named route: 'gallery') -->
                        <a href="{{ route('gallery') }}" 
                           class="relative group px-7 py-4 rounded-xl text-sm font-semibold tracking-wide text-slate-200 bg-dark-850/80 hover:bg-dark-750 hover:text-cyan-300 border border-white/[0.12] hover:border-cyan-400/50 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.3)] transition-all duration-300 magnetic-btn flex items-center gap-2">
                            <i data-lucide="grid" class="w-4 h-4 text-cyan-400"></i>
                            Jelajahi Galeri
                            <span class="w-2 h-2 rounded-full bg-cyan-400/50 group-hover:bg-cyan-400 transition-colors"></span>
                        </a>

                    </div>

                    <!-- Quick Terminal/Stack Pill Indicators -->
                    <div class="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-2 text-xs font-mono text-slate-400">
                        <span class="text-slate-500">Core Stack:</span>
                        <span class="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-slate-300">Laravel 13 (MVC)</span>
                        <span class="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-slate-300">Tailwind CSS</span>
                        <span class="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-slate-300">Modern ES6+</span>
                        <span class="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-cyan-300">Blade Engine</span>
                    </div>

                </div>

                <!-- Right Column: Interactive 3D Holographic Artifact (Antigravity Inspired) -->
                <div class="lg:col-span-5 relative flex items-center justify-center">
                    
                    <!-- Main 3D Tilt Card Interactive Object -->
                    <div class="relative w-full max-w-md tilt-card" data-tilt-max="14" data-tilt-glare="true">
                        
                        <!-- Glowing Cyber Frame & Backdrop Blur -->
                        <div class="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-dark-850/90 via-dark-900/90 to-dark-950/90 border border-cyan-500/30 backdrop-blur-2xl shadow-[0_10px_50px_rgba(0,0,0,0.6)] group transition-all duration-500 hover:border-cyan-400/70 hover:shadow-[0_0_40px_rgba(6,182,212,0.3)]">
                            
                            <!-- Card Header Bar -->
                            <div class="flex items-center justify-between pb-5 mb-6 border-b border-white/[0.08]">
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 rounded-full bg-rose-500/80"></div>
                                    <div class="w-3 h-3 rounded-full bg-amber-500/80"></div>
                                    <div class="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                                </div>
                                <div class="text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
                                    <i data-lucide="terminal" class="w-3.5 h-3.5 text-cyan-400"></i>
                                    <span>node://antigravity-core</span>
                                </div>
                            </div>

                            <!-- Futuristic Profile Visual Avatar & Status Halo -->
                            <div class="relative mb-6 flex justify-center">
                                <div class="relative group">
                                    <!-- Rotating Neon Rings -->
                                    <div class="absolute -inset-2 rounded-full bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 opacity-60 blur-md group-hover:opacity-100 transition-opacity duration-500"></div>
                                    <div class="relative w-32 h-32 sm:w-36 sm:h-36 rounded-full overflow-hidden border-2 border-cyan-400/80 bg-dark-900 p-1">
                                        <img src="{{ asset('images/profile.jpg') }}" 
                                             alt="{{ $name }}" 
                                             class="w-full h-full object-cover rounded-full transition-transform duration-500 group-hover:scale-110">
                                    </div>
                                    <!-- Online Status Badge -->
                                    <div class="absolute bottom-1 right-1 p-1.5 rounded-full bg-dark-900 border border-emerald-400/50" title="Online Active">
                                        <div class="w-3.5 h-3.5 rounded-full bg-emerald-400 animate-pulse"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Profile Card Info Details -->
                            <div class="text-center space-y-2 mb-6">
                                <h3 class="font-display font-bold text-xl text-white">
                                    {{ $name }}
                                </h3>
                                <p class="text-xs font-mono text-cyan-400">
                                    Lead Architect & System Designer
                                </p>
                                <p class="text-xs text-slate-400 max-w-xs mx-auto">
                                    "Fusing logical software architecture with fluid sensory interaction."
                                </p>
                            </div>

                            <!-- Interactive Telemetry Grid Inside Card -->
                            <div class="grid grid-cols-2 gap-3 p-3 rounded-xl bg-dark-950/70 border border-white/[0.06] text-left font-mono text-xs mb-4">
                                <div>
                                    <span class="text-slate-500 block text-[10px]">CURRENT FOCUS</span>
                                    <span class="text-cyan-300 font-medium">Reactive Web Physics</span>
                                </div>
                                <div>
                                    <span class="text-slate-500 block text-[10px]">FRAMEWORK</span>
                                    <span class="text-purple-300 font-medium">Laravel 13 MVC</span>
                                </div>
                                <div>
                                    <span class="text-slate-500 block text-[10px]">BASE LOCATION</span>
                                    <span class="text-slate-300">Bandung, Indonesia</span>
                                </div>
                                <div>
                                    <span class="text-slate-500 block text-[10px]">SYSTEM STATUS</span>
                                    <span class="text-emerald-400">Available</span>
                                </div>
                            </div>

                            <!-- Card Bottom Action -->
                            <div class="pt-2">
                                <a href="{{ route('about') }}" 
                                   class="w-full py-2.5 px-4 rounded-xl text-xs font-semibold uppercase tracking-wider text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 hover:border-cyan-400 transition-all duration-300 flex items-center justify-center gap-2 group">
                                    <span>Buka Kartu Identitas Lengkap</span>
                                    <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"></i>
                                </a>
                            </div>

                        </div>

                        <!-- Floating Decorative Badges (Parallax Reactivity) -->
                        <div class="parallax-float hidden sm:flex absolute -top-5 -right-6 items-center gap-2 px-3.5 py-2 rounded-xl bg-dark-850/90 border border-purple-500/40 backdrop-blur-xl shadow-xl text-xs font-mono text-purple-300 animate-float-slow" data-float-speed="2">
                            <i data-lucide="cpu" class="w-4 h-4 text-purple-400"></i>
                            <span>Inertia Engine 60FPS</span>
                        </div>

                        <div class="parallax-float hidden sm:flex absolute -bottom-5 -left-6 items-center gap-2 px-3.5 py-2 rounded-xl bg-dark-850/90 border border-cyan-500/40 backdrop-blur-xl shadow-xl text-xs font-mono text-cyan-300 animate-float-delayed" data-float-speed="-1.5">
                            <i data-lucide="shield-check" class="w-4 h-4 text-cyan-400"></i>
                            <span>Clean MVC Architecture</span>
                        </div>

                    </div>

                </div>

            </div>
        </div>

        <!-- Scroll Indicator Down Arrow -->
        <div class="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-none opacity-70 hover:opacity-100 transition-opacity">
            <span class="text-[10px] font-mono tracking-widest uppercase text-slate-400">Scroll to explore</span>
            <div class="w-5 h-9 rounded-full border-2 border-slate-600 flex items-start justify-center p-1">
                <div class="w-1.5 h-2.5 rounded-full bg-cyan-400 animate-bounce"></div>
            </div>
        </div>

    </section>

    <!-- ========================================================================= -->
    <!-- METRICS & KEY IMPACT COUNTERS SECTION                                     -->
    <!-- ========================================================================= -->
    <section class="relative py-16 border-y border-white/[0.08] bg-[#050814]/70 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                @foreach($metrics as $index => $item)
                    <div class="reveal-on-scroll delay-{{ ($index + 1) * 100 }} p-6 rounded-2xl bg-dark-850/50 border border-white/[0.06] hover:border-cyan-500/30 transition-all duration-300 group tilt-card" data-tilt-max="8">
                        <div class="flex items-baseline justify-between mb-2">
                            <span class="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 group-hover:from-cyan-300 group-hover:to-purple-300 transition-colors">
                                {{ $item['value'] }}
                            </span>
                            <span class="text-xs font-mono text-cyan-400/60 font-medium">#0{{ $index + 1 }}</span>
                        </div>
                        <h4 class="text-sm sm:text-base font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors">
                            {{ $item['label'] }}
                        </h4>
                        <p class="text-xs text-slate-400 mt-1 font-mono">
                            {{ $item['sub'] }}
                        </p>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- ========================================================================= -->
    <!-- CORE PILLARS & ARCHITECTURAL PHILOSOPHY SECTION                          -->
    <!-- ========================================================================= -->
    <section class="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto">
            
            <!-- Section Header -->
            <div class="text-center max-w-3xl mx-auto mb-16 sm:mb-20 space-y-4 reveal-on-scroll">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-mono text-cyan-300">
                    <i data-lucide="layers" class="w-3.5 h-3.5"></i>
                    ARCHITECTURAL CORE
                </div>
                <h2 class="text-3xl sm:text-5xl font-display font-bold text-white tracking-tight">
                    Pilar Desain & Standar Rekayasa
                </h2>
                <p class="text-slate-400 text-sm sm:text-base leading-relaxed">
                    Setiap baris kode, animasi kursor, dan struktur controller dibangun dengan filosofi modernitas, keamanan tingkat tinggi, serta estetika visual terinspirasi Google Antigravity IDE.
                </p>
            </div>

            <!-- Pillars Cards Grid (3D Tilt & Staggered Scroll Animation) -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                @foreach($corePillars as $index => $pillar)
                    <div class="reveal-on-scroll delay-{{ ($index + 1) * 150 }} relative rounded-2xl p-7 bg-gradient-to-b from-dark-850/80 to-dark-900/90 border border-white/[0.08] hover:border-cyan-400/50 backdrop-blur-xl shadow-lg transition-all duration-500 group tilt-card" data-tilt-max="12">
                        
                        <!-- Top Pill Badge -->
                        <div class="flex items-center justify-between mb-6">
                            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-600/20 border border-cyan-400/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all duration-300">
                                <i data-lucide="{{ $pillar['icon'] }}" class="w-6 h-6"></i>
                            </div>
                            <span class="text-[10px] font-mono uppercase px-2.5 py-1 rounded-md bg-white/[0.04] text-slate-400 border border-white/[0.06]">
                                {{ $pillar['badge'] }}
                            </span>
                        </div>

                        <!-- Pillar Title & Desc -->
                        <h3 class="font-display font-bold text-lg text-white mb-3 group-hover:text-cyan-300 transition-colors">
                            {{ $pillar['title'] }}
                        </h3>
                        <p class="text-sm text-slate-400 leading-relaxed">
                            {{ $pillar['desc'] }}
                        </p>

                        <!-- Subtle Bottom Indicator -->
                        <div class="mt-6 pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs font-mono text-slate-400">
                            <span>Status: Verified</span>
                            <i data-lucide="arrow-right" class="w-4 h-4 text-cyan-400 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all duration-300"></i>
                        </div>

                    </div>
                @endforeach
            </div>

        </div>
    </section>

    <!-- ========================================================================= -->
    <!-- BOTTOM CALL-TO-ACTION SECTION                                             -->
    <!-- ========================================================================= -->
    <section class="relative py-20 px-4 sm:px-6 lg:px-8">
        <div class="max-w-5xl mx-auto">
            <div class="relative rounded-3xl p-8 sm:p-14 overflow-hidden border border-cyan-500/30 bg-gradient-to-r from-dark-850/90 via-dark-900/95 to-dark-950/90 backdrop-blur-2xl shadow-[0_20px_60px_rgba(0,0,0,0.6)] text-center space-y-6 reveal-on-scroll">
                
                <!-- Background Glow -->
                <div class="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full bg-cyan-500/20 blur-3xl pointer-events-none"></div>

                <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
                    <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                    EXPLORE FULL PROFILE
                </div>

                <h2 class="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight">
                    Siap Memulai Eksplorasi Profil & Galeri?
                </h2>

                <p class="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
                    Temukan data diri lengkap, riwayat pendidikan formal, portofolio keahlian teknis, dan galeri interaktif dengan lightbox modern.
                </p>

                <div class="flex flex-wrap items-center justify-center gap-4 pt-4">
                    <a href="{{ route('about') }}" 
                       class="px-8 py-4 rounded-xl text-sm font-semibold tracking-wide text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-[0_0_25px_rgba(6,182,212,0.4)] transition-all duration-300 magnetic-btn flex items-center gap-2">
                        <i data-lucide="user-check" class="w-4 h-4"></i>
                        Buka Halaman About Me
                    </a>
                    <a href="{{ route('gallery') }}" 
                       class="px-8 py-4 rounded-xl text-sm font-semibold tracking-wide text-slate-200 bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.12] hover:border-cyan-400/50 transition-all duration-300 magnetic-btn flex items-center gap-2">
                        <i data-lucide="eye" class="w-4 h-4 text-cyan-400"></i>
                        Lihat 6 Galeri Proyek
                    </a>
                </div>

            </div>
        </div>
    </section>

</div>
@endsection
