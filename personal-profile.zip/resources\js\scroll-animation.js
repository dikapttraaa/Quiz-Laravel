const revealItems = document.querySelectorAll('.reveal');

if (typeof IntersectionObserver === 'undefined') {
    revealItems.forEach((item) => item.classList.add('visible'));
} else {
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.18 });

    document.documentElement.classList.add('has-scroll-reveal');
    revealItems.forEach((item) => revealObserver.observe(item));
}
