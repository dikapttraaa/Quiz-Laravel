# Personal Profile Website

A futuristic personal portfolio built with Laravel Blade, Tailwind CSS, and Vite.

## Features

- Welcome hero section with animated gradients and interactive cursor highlight
- About Me section with profile cards and repeated data loops
- Responsive gallery with modal lightbox and hover effects
- Sticky glass-style header and footer
- Tailwind-based styling with JavaScript for motion and interactions

## Structure

- `app/Http/Controllers/ProfileController.php`
- `resources/views/layouts/app.blade.php`
- `resources/views/components/header.blade.php`
- `resources/views/components/footer.blade.php`
- `resources/views/pages/welcome.blade.php`
- `resources/views/pages/about.blade.php`
- `resources/views/pages/gallery.blade.php`
- `resources/js/`
- `resources/css/app.css`

## Installation

1. Install PHP, Composer, and Node.js.
2. Run `composer install`.
3. Copy `.env.example` to `.env`, then run `php artisan key:generate`.
4. Run `npm install` and `npm run build`.
5. Start the app with `php artisan serve`.
