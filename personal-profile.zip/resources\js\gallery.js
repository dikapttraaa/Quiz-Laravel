const modal = document.getElementById('gallery-modal');
const modalVideo = document.getElementById('gallery-modal-video');
const modalTitle = document.getElementById('gallery-modal-title');
const modalDescription = document.getElementById('gallery-modal-description');
const playbackError = document.getElementById('gallery-modal-playback-error');
const galleryButtons = document.querySelectorAll('[data-gallery-open]');
const closeButton = document.getElementById('gallery-modal-close');
const galleryToggle = document.querySelector('[data-gallery-toggle]');
const extraGalleryItems = document.querySelectorAll('[data-gallery-extra-item]');
let previouslyFocusedElement = null;
let closeTimeout;

galleryButtons.forEach((button) => {
    button.addEventListener('click', () => {
        if (!modal || !modalVideo || !modalTitle || !modalDescription) return;

        window.clearTimeout(closeTimeout);
        previouslyFocusedElement = button;
        modalVideo.pause();
        modalVideo.muted = false;
        modalVideo.src = button.dataset.video;
        modalVideo.load();
        modalTitle.textContent = button.dataset.title;
        modalDescription.textContent = button.dataset.description;
        playbackError?.classList.add('hidden');
        modal.classList.remove('is-closing');
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
        closeButton?.focus();

        modalVideo.play().catch(() => {
            playbackError?.classList.remove('hidden');
        });
    });
});

galleryToggle?.addEventListener('click', () => {
    const isExpanded = galleryToggle.getAttribute('aria-expanded') === 'true';
    galleryToggle.setAttribute('aria-expanded', String(!isExpanded));
    galleryToggle.querySelector('span')?.replaceChildren(document.createTextNode(isExpanded ? '↓' : '↑'));

    extraGalleryItems.forEach((item) => {
        const video = item.querySelector('video');
        item.classList.toggle('hidden', isExpanded);

        if (!video) return;

        if (isExpanded) {
            video.pause();
            return;
        }

        if (!video.src && video.dataset.videoSrc) {
            video.src = video.dataset.videoSrc;
            video.load();
        }

        video.play().catch(() => {
            video.controls = true;
        });
    });
});

const closeModal = () => {
    if (!modal) return;
    window.clearTimeout(closeTimeout);
    modalVideo?.pause();
    modal.classList.add('is-closing');
    document.body.classList.remove('overflow-hidden');
    closeTimeout = window.setTimeout(() => {
        modal.classList.add('hidden');
        modal.classList.remove('is-closing');

        if (modalVideo) {
            modalVideo.removeAttribute('src');
            modalVideo.load();
        }

        previouslyFocusedElement?.focus();
    }, 180);
};

closeButton?.addEventListener('click', closeModal);
modal?.addEventListener('click', (event) => {
    if (event.target === modal) closeModal();
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && modal && !modal.classList.contains('hidden')) {
        closeModal();
    }
});
