const magnetics = document.querySelectorAll('.magnetic');

if (window.matchMedia('(hover: hover) and (pointer: fine)').matches
    && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
magnetics.forEach((button) => {
    button.addEventListener('pointermove', (event) => {
        const rect = button.getBoundingClientRect();
        const offsetX = (event.clientX - rect.left - rect.width / 2) / 10;
        const offsetY = (event.clientY - rect.top - rect.height / 2) / 10;
        button.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
    });

    button.addEventListener('pointerleave', () => {
        button.style.transform = 'translate(0, 0)';
    });
});
}
