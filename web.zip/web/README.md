# ANTIGRAVITY — Interactive Futuristic Personal Profile & Portfolio

Website Personal Profile & Portfolio modern, futuristik, dan interaktif yang terinspirasi oleh pengalaman visual dan filosofi eksperimental **Google Antigravity IDE**. Proyek ini dibangun menggunakan **Laravel 13 (MVC)**, **Blade Template Engine**, **Tailwind CSS**, dan modul **JavaScript ES6+** murni dengan fisika inersia 60 FPS.

---

## 🚀 Fitur Unggulan

1. **Interactive Cursor Follower (Fitur Utama)**
   - Objek bercahaya ganda (`.cursor-dot` dan `.cursor-glow`) dengan interpolasi inersia (lerp) dan massa cairan.
   - Perubahan ukuran dan intensitas pancaran cahaya secara dinamis saat kursor mendekati tombol, link, dan card.
   - Berjalan pada siklus `requestAnimationFrame` untuk efisiensi GPU 60 FPS tanpa lag.
   - Nonaktif otomatis pada perangkat layar sentuh (touchscreen) dan pengguna preferensi `prefers-reduced-motion`.

2. **Interactive 3D Tilt & Parallax Physics**
   - Efek kemiringan 3D interaktif pada setiap card berdasarkan posisi koordinat mouse dengan lapisan pantulan cahaya (*glare sheen*).
   - Efek multi-lapisan parallax pada latar belakang ambient grid dan floating badges.

3. **Magnetic Button Dynamics**
   - Tombol-tombol CTA memiliki daya tarik magnetik halus yang menarik tombol ke arah kursor saat didekati.

4. **Koleksi Galeri & Lightbox Interaktif**
   - Grid galeri responsif berbasis looping Blade `@foreach` dari controller.
   - Lightbox modal lengkap dengan navigasi Previous/Next, keyboard controls (`Esc`, `ArrowLeft`, `ArrowRight`), dan tombol salin link.

5. **Mode Tema Gelap & Terang (Cyberpunk Dark & Clean Light)**
   - Tombol toggle mode gelap/terang dengan persistensi status di `localStorage`.

6. **Arsitektur Kode MVC Bersih**
   - Seluruh data nama, bio, metrik, data diri, pendidikan, skill, hobi, dan galeri dikelola melalui `ProfileController.php` dan dikirim ke view Blade tanpa ada hardcode pada template.

---

## 📂 Struktur Folder Proyek

```text
personal-profile/
├── app/
│   └── Http/
│       └── Controllers/
│           └── ProfileController.php          # Controller utama penyedia data profil & galeri
├── resources/
│   ├── views/
│   │   ├── layouts/
│   │   │   └── app.blade.php                  # Layout master Blade dengan cursor & ambient grid
│   │   ├── components/
│   │   │   ├── header.blade.php               # Header navbar sticky glassmorphism
│   │   │   └── footer.blade.php               # Footer futuristik dengan copyright & medsos
│   │   └── pages/
│   │       ├── welcome.blade.php              # Halaman pembuka / Hero futuristik
│   │       ├── about.blade.php                # Halaman biodata diri lengkap & skill matrix
│   │       └── gallery.blade.php              # Halaman galeri portofolio & lightbox
│   ├── css/
│   │   └── app.css                            # Styling kustom, neon glow, cursor, dan 3D tilt
│   └── js/
│       ├── app.js                             # Orkestrator tema, mobile menu, toast & lucide
│       ├── cursor-follower.js                 # Logika kursor inersia & glowing orb
│       ├── parallax.js                        # Logika parallax background & 3D tilt card
│       ├── magnetic-button.js                 # Logika tarikan magnetik pada tombol
│       ├── scroll-animation.js                # Intersection observer reveal & back-to-top
│       └── gallery.js                         # Logika modal lightbox & keyboard navigation
├── public/
│   ├── css/
│   │   └── app.css                            # Stylesheet siap saji runtime
│   ├── js/
│   │   ├── app.js
│   │   ├── cursor-follower.js
│   │   ├── parallax.js
│   │   ├── magnetic-button.js
│   │   ├── scroll-animation.js
│   │   └── gallery.js
│   └── images/
│       ├── profile.jpg                        # Foto profil pengguna (dapat diganti)
│       └── gallery/
│           ├── gallery1.jpg
│           ├── gallery2.jpg
│           ├── gallery3.jpg
│           ├── gallery4.jpg
│           ├── gallery5.jpg
│           └── gallery6.jpg
├── routes/
│   └── web.php                                # Rute named: welcome, about, gallery
├── vite.config.js                             # Konfigurasi Vite
└── package.json                               # Dependensi Vite & Tailwind
```

---

## ⚡ Panduan Menjalankan Project

Website ini telah disiapkan agar dapat **langsung dijalankan** dengan PHP dan Laravel:

### 1. Jalankan Server Laravel

Buka terminal pada direktori proyek dan jalankan perintah:

```bash
php artisan serve
```

Server lokal akan aktif di:
👉 **http://127.0.0.1:8000**

Buka tautan di atas pada peramban (Chrome, Edge, Firefox, atau Safari) untuk menikmati pengalaman visual interaktif futuristik secara langsung!

---

## 🎨 Panduan Kustomisasi Data & Foto

1. **Mengubah Nama dan Data Diri**:
   Buka file `app/Http/Controllers/ProfileController.php`. Ubah nilai pada method `getProfileData()` untuk mengganti nama, email, alamat, tempat/tanggal lahir, cita-cita, dan jejaring sosial.

2. **Mengganti Foto Profil**:
   Cukup letakkan foto baru Anda pada path `public/images/profile.jpg` (disarankan rasio 1:1 / persegi), atau ubah nilai `'photo'` pada `ProfileController.php`.

3. **Mengganti Gambar Galeri**:
   Ganti file-file gambar di `public/images/gallery/gallery1.jpg` hingga `gallery6.jpg`, lalu sesuaikan judul dan deskripsi proyek pada array `$galleries` di method `gallery()` pada `ProfileController.php`.
