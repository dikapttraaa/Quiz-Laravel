

<?php $__env->startSection('content'); ?>
<section class="relative overflow-hidden px-4 pb-20 pt-10 sm:px-6 lg:px-8">
    <div class="pointer-events-none absolute inset-0 overflow-hidden">
        <div data-parallax="1.5" class="hero-orb left-[8%] top-12 h-64 w-64 bg-violet-500/25"></div>
        <div data-parallax="1.8" class="hero-orb right-[10%] top-20 h-72 w-72 bg-cyan-500/20"></div>
        <div data-parallax="-1.2" class="hero-orb bottom-24 left-1/2 h-52 w-52 bg-indigo-500/20"></div>
    </div>

    <div class="relative mx-auto max-w-7xl">
        <div class="grid items-center gap-14 lg:grid-cols-[1.2fr_0.8fr]">
            <div class="reveal">
                <div class="inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-500/10 px-4 py-2 text-xs font-medium uppercase tracking-[0.3em] text-cyan-200">
                    <span class="h-2 w-2 rounded-full bg-cyan-300 shadow-[0_0_16px_rgba(103,232,249,0.8)]"></span>
                    Ready to build
                </div>

                <h1 class="mt-8 text-4xl font-black tracking-[-0.08em] text-white sm:text-5xl lg:text-7xl">
                    Hello, I'm <span class="gradient-text"><?php echo e($profile['first_name']); ?></span>
                </h1>

                <p class="mt-6 max-w-xl text-lg leading-relaxed text-slate-300">
                    <?php echo e($profile['title']); ?> <span class="text-cyan-200"><?php echo e($profile['tagline']); ?></span>
                </p>

                <div class="mt-10 flex flex-wrap gap-4">
                    <a href="<?php echo e(route('about')); ?>" class="magnetic inline-flex items-center justify-center rounded-full border border-cyan-400/40 bg-gradient-to-r from-cyan-500/20 to-violet-500/20 px-6 py-3 text-sm font-semibold text-white shadow-glow transition hover:shadow-[0_0_30px_rgba(34,211,238,0.35)]">
                        Lihat Profil Saya
                    </a>
                    <a href="<?php echo e(route('gallery')); ?>" class="magnetic inline-flex items-center justify-center rounded-full border border-white/10 bg-white/5 px-6 py-3 text-sm font-semibold text-slate-100 transition hover:border-violet-400/50 hover:bg-violet-500/10">
                        Jelajahi Galeri
                    </a>
                </div>

                <div class="mt-12 flex flex-wrap gap-6 text-sm text-slate-300">
                    <div>
                        <p class="text-2xl font-bold text-white">4+</p>
                        <p>Years Experience</p>
                    </div>
                    <div>
                        <p class="text-2xl font-bold text-white">30+</p>
                        <p>Projects</p>
                    </div>
                    <div>
                        <p class="text-2xl font-bold text-white">24/7</p>
                        <p>Creative Mindset</p>
                    </div>
                </div>
            </div>

            <div class="reveal relative mx-auto w-full max-w-md">
                <div class="relative overflow-hidden rounded-[2rem] border border-white/10 bg-slate-900/60 p-4 shadow-[0_30px_80px_rgba(15,23,42,0.8)] backdrop-blur-xl">
                    <div class="absolute inset-0 bg-gradient-to-br from-cyan-400/10 via-violet-500/10 to-transparent"></div>
                    <div class="relative rounded-[1.5rem] border border-white/10 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 p-5">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <span class="h-3 w-3 rounded-full bg-rose-400"></span>
                                <span class="h-3 w-3 rounded-full bg-yellow-400"></span>
                                <span class="h-3 w-3 rounded-full bg-emerald-400"></span>
                            </div>
                            <span class="rounded-full border border-cyan-400/20 bg-cyan-500/10 px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-cyan-200">Live</span>
                        </div>

                        <div class="mt-6 overflow-hidden rounded-2xl border border-white/10 bg-slate-950/80 p-4">
                            <div class="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-slate-400">
                                <span>Portfolio</span>
                                <span>2026</span>
                            </div>
                            <div class="mt-6 flex items-center gap-4">
                                <img src="/images/profile.svg" alt="Profile" class="h-24 w-24 rounded-2xl object-cover ring-2 ring-cyan-500/40 shadow-glow" />
                                <div>
                                    <p class="text-xl font-bold text-white"><?php echo e($profile['full_name']); ?></p>
                                    <p class="mt-1 text-sm text-cyan-200"><?php echo e($profile['title']); ?></p>
                                </div>
                            </div>

                            <div class="mt-6 space-y-3 text-sm text-slate-300">
                                <div class="flex items-center justify-between rounded-xl border border-white/5 bg-white/5 px-3 py-2">
                                    <span>Location</span>
                                    <span class="text-white"><?php echo e($profile['location']); ?></span>
                                </div>
                                <div class="flex items-center justify-between rounded-xl border border-white/5 bg-white/5 px-3 py-2">
                                    <span>Email</span>
                                    <span class="text-white"><?php echo e($profile['email']); ?></span>
                                </div>
                                <div class="flex items-center justify-between rounded-xl border border-white/5 bg-white/5 px-3 py-2">
                                    <span>Website</span>
                                    <span class="text-white"><?php echo e($profile['website']); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\Quiz-Laravel\personal-profile\resources\views/pages/welcome.blade.php ENDPATH**/ ?>