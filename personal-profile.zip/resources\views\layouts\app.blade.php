<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>{{ $title ?? 'Personal Profile' }}</title>
        <meta name="description" content="Futuristic personal profile portfolio built with Laravel and Tailwind CSS." />
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="selection:bg-cyan-500/30 selection:text-slate-100">
        <div class="ambient-orbs" aria-hidden="true">
            <span class="ambient-orb ambient-orb--violet"></span>
            <span class="ambient-orb ambient-orb--cyan"></span>
            <span class="ambient-orb ambient-orb--blue"></span>
            <span class="ambient-orb ambient-orb--pink"></span>
            <span class="ambient-orb ambient-orb--orange"></span>
            <span class="ambient-orb ambient-orb--green"></span>
            <span class="ambient-orb ambient-orb--rose"></span>
            <span class="ambient-orb ambient-orb--indigo"></span>
        </div>
        <div
            x-data="cursorTrail"
            @pointermove.window="move($event)"
            @pointerleave.window="hide()"
            @pointerout.window="if (!$event.relatedTarget) hide()"
            @pointercancel.window="hide()"
            @blur.window="hide()"
            class="cursor-trail pointer-events-none fixed inset-0 z-[59] overflow-hidden"
            aria-hidden="true"
        >
            @for ($index = 0; $index < 12; $index++)
                <span
                    class="cursor-trail-particle"
                    style="--trail-scale: {{ 0.95 - ($index * 0.055) }}; --trail-opacity: {{ 0.68 - ($index * 0.04) }}"
                ></span>
            @endfor
        </div>
        <div id="app">
            @include('components.header')
            <main class="relative z-10">
                @yield('content')
            </main>
            @include('components.footer')
        </div>
        @include('components.bottom-navigation')
    </body>
</html>
