<?php

namespace Tests\Feature;

// use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     */
    public function test_the_application_returns_a_successful_response(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function test_the_about_page_uses_profile_data_consistently(): void
    {
        $response = $this->get('/about');

        $response
            ->assertOk()
            ->assertSee('31 Januari 2007')
            ->assertSee('SMP Negeri 9 Denpasar')
            ->assertSee('Membaca')
            ->assertDontSee('SMK Informatika Bandung');
    }

    public function test_the_gallery_page_renders_video_entries(): void
    {
        $response = $this->get('/gallery');

        $response
            ->assertOk()
            ->assertSee('Video 1')
            ->assertSee('Video 9');
    }
}
