<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title><?php echo e($title ?? 'Personal Profile'); ?></title>
        <meta name="description" content="Futuristic personal profile portfolio built with Laravel and Tailwind CSS." />
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="selection:bg-cyan-500/30 selection:text-slate-100">
        <div class="ambient-orbs" aria-hidden="true">
            <span class="ambient-orb ambient-orb--violet"></span>
            <span class="ambient-orb ambient-orb--cyan"></span>
            <span class="ambient-orb ambient-orb--blue"></span>
            <span class="ambient-orb ambient-orb--pink"></span>
            <span class="ambient-orb ambient-orb--orange"></span>
            <span class="ambient-orb ambient-orb--green"></span>
            <span class="ambient-orb ambient-orb--rose"></span>
            <span class="ambient-orb ambient-orb--indigo"></span>
        </div>
        <div
            x-data="cursorTrail"
            @pointermove.window="move($event)"
            @pointerleave.window="hide()"
            @pointerout.window="if (!$event.relatedTarget) hide()"
            @pointercancel.window="hide()"
            @blur.window="hide()"
            class="cursor-trail pointer-events-none fixed inset-0 z-[59] overflow-hidden"
            aria-hidden="true"
        >
            <?php for($index = 0; $index < 12; $index++): ?>
                <span
                    class="cursor-trail-particle"
                    style="--trail-scale: <?php echo e(0.95 - ($index * 0.055)); ?>; --trail-opacity: <?php echo e(0.68 - ($index * 0.04)); ?>"
                ></span>
            <?php endfor; ?>
        </div>
        <div id="app">
            <?php echo $__env->make('components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <main class="relative z-10">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <?php echo $__env->make('components.bottom-navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </body>
</html>
<?php /**PATH C:\Users\LENOVO\Downloads\Quiz-Laravel\personal-profile\resources\views/layouts/app.blade.php ENDPATH**/ ?>