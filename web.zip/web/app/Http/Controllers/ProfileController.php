<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    /**
     * Data master profil pengguna.
     * Dapat disesuaikan dengan mudah untuk mengganti data pemilik profil.
     */
    protected function getProfileData(): array
    {
        return [
            'name' => 'Andika Pratama',
            'nickname' => 'Andika',
            'title' => 'Full-Stack Software Architect & UI Engineer',
            'role' => 'Creative Technologist & System Architect',
            'tagline' => 'Architecting Scalable Systems & Immersive Futuristic Web Interfaces',
            'bio_short' => 'Menggabungkan rekayasa backend enterprise yang kokoh dengan pengalaman antarmuka visual futuristik, interaktif, dan berkinerja tinggi yang terinspirasi oleh filosofi eksperimental Antigravity.',
            'bio_full' => 'Saya adalah seorang Software Architect dan Creative Developer yang berfokus pada perancangan arsitektur web modern, sistem terdistribusi, dan antarmuka pengguna interaktif masa depan. Dengan latar belakang mendalam di bidang Computer Science dan ketertarikan kuat pada interaksi manusia-komputer (HCI), saya selalu berusaha menghadirkan aplikasi web yang tidak hanya stabil dan aman, tetapi juga terasa hidup, dinamis, serta memberikan kepuasan estetika visual.',
            'birth_place_date' => 'Bandung, 14 April 2002',
            'age' => 24,
            'gender' => 'Laki-laki',
            'address' => 'Jl. Antigravity Cyberway No. 42, Dago, Bandung, Jawa Barat, Indonesia',
            'email' => 'andika.pratama@antigravity.dev',
            'phone' => '+62 812-3456-7890',
            'status' => 'Available for Architecture & Projects',
            'photo' => 'images/profile.jpg',
            'aspirations' => [
                'Membangun platform teknologi dan arsitektur sistem cerdas kelas dunia yang memberdayakan jutaan pengguna di Asia Tenggara.',
                'Menjadi pelopor pengembangan Human-Computer Interface masa depan yang mengaburkan batas antara web statis dan spatial interactive computing.'
            ],
            'socials' => [
                ['name' => 'GitHub', 'icon' => 'github', 'url' => 'https://github.com', 'handle' => '@andika-dev'],
                ['name' => 'LinkedIn', 'icon' => 'linkedin', 'url' => 'https://linkedin.com', 'handle' => 'Andika Pratama'],
                ['name' => 'Instagram', 'icon' => 'instagram', 'url' => 'https://instagram.com', 'handle' => '@andika.codes'],
                ['name' => 'Twitter/X', 'icon' => 'twitter', 'url' => 'https://twitter.com', 'handle' => '@andika_tech'],
                ['name' => 'Email', 'icon' => 'mail', 'url' => 'mailto:andika.pratama@antigravity.dev', 'handle' => 'andika.pratama@antigravity.dev'],
            ]
        ];
    }

    /**
     * Halaman Utama (Welcome Page)
     */
    public function welcome()
    {
        $profile = $this->getProfileData();

        $metrics = [
            ['value' => '5+', 'label' => 'Tahun Pengalaman', 'sub' => 'Enterprise & Modern Web'],
            ['value' => '42+', 'label' => 'Proyek Selesai', 'sub' => 'Full-Stack & Cloud Architecture'],
            ['value' => '99.9%', 'label' => 'Client Satisfaction', 'sub' => 'Production SLA Grade'],
            ['value' => '1.2M+', 'label' => 'Lines of Code', 'sub' => 'Clean, Tested & Optimized'],
        ];

        $corePillars = [
            [
                'title' => 'Reactive Motion & Fluid Physics',
                'desc' => 'Desain visual futuristik terinspirasi Antigravity IDE dengan kursor reaktif ber-inersia, parallax multi-lapisan, dan efek visual 60fps tanpa lag.',
                'icon' => 'sparkles',
                'badge' => 'Interactive UI'
            ],
            [
                'title' => 'Resilient Backend Architecture',
                'desc' => 'Infrastruktur Laravel MVC modular, asynchronous event queues, database terdistribusi, dan API berkecepatan mikrodetik.',
                'icon' => 'cpu',
                'badge' => 'High Concurrency'
            ],
            [
                'title' => 'Zero-Trust Cyber Governance',
                'desc' => 'Penerapan standar keamanan industri, sanitasi kriptografis, arsitektur berbasis tokens, dan proteksi integritas data.',
                'icon' => 'shield-check',
                'badge' => 'Enterprise Security'
            ],
            [
                'title' => 'Future-Ready Scalability',
                'desc' => 'Struktur kode berstandar enterprise yang siap bermigrasi ke cloud native, containerization, dan integrasi kecerdasan buatan.',
                'icon' => 'layers',
                'badge' => 'Cloud Native'
            ]
        ];

        return view('pages.welcome', [
            'name' => $profile['name'],
            'nickname' => $profile['nickname'],
            'role' => $profile['role'],
            'tagline' => $profile['tagline'],
            'bioShort' => $profile['bio_short'],
            'profile' => $profile,
            'metrics' => $metrics,
            'corePillars' => $corePillars,
        ]);
    }

    /**
     * Halaman Data Diri (About Me)
     */
    public function about()
    {
        $profile = $this->getProfileData();

        // Data informasi personal untuk looping @foreach
        $personalDetails = [
            ['label' => 'Nama Lengkap', 'value' => $profile['name'], 'icon' => 'user-check', 'badge' => 'Identitas Resmi'],
            ['label' => 'Nama Panggilan', 'value' => $profile['nickname'], 'icon' => 'smile', 'badge' => 'Casual'],
            ['label' => 'Tempat & Tgl Lahir', 'value' => $profile['birth_place_date'], 'icon' => 'calendar-days', 'badge' => 'Kelahiran'],
            ['label' => 'Usia Sekarang', 'value' => $profile['age'] . ' Tahun', 'icon' => 'hourglass', 'badge' => 'Prime Age'],
            ['label' => 'Jenis Kelamin', 'value' => $profile['gender'], 'icon' => 'sparkle', 'badge' => 'Gender'],
            ['label' => 'Alamat Domisili', 'value' => $profile['address'], 'icon' => 'map-pin', 'badge' => 'Bandung, ID'],
            ['label' => 'Email Kontak', 'value' => $profile['email'], 'icon' => 'mail', 'badge' => 'Primary'],
            ['label' => 'Nomor Telepon', 'value' => $profile['phone'], 'icon' => 'phone-call', 'badge' => 'WhatsApp Active'],
            ['label' => 'Status Profesional', 'value' => $profile['status'], 'icon' => 'briefcase', 'badge' => 'Open to Work'],
        ];

        // Data Riwayat Pendidikan untuk looping @foreach
        $educations = [
            [
                'period' => '2020 — 2024',
                'institution' => 'Institut Teknologi Bandung (ITB)',
                'degree' => 'Sarjana Komputer (S.Kom) - Teknik Informatika',
                'gpa' => 'IPK: 3.92 / 4.00 (Cum Laude)',
                'thesis' => 'Tugas Akhir: Desain Sistem Terdistribusi Berbasis Microservices & Real-Time Telemetry',
                'description' => 'Mendalami perancangan sistem komputasi berkinerja tinggi, struktur data lanjutan, kriptografi modern, dan rekayasa antarmuka pengguna interaktif (HCI).',
                'achievements' => ['Juara 1 Software Design Competition Nasional', 'Ketua Divisi Riset Laboratorium Rekayasa Perangkat Lunak', 'Publikasi Jurnal Terakreditasi'],
                'icon' => 'graduation-cap',
                'badge' => 'Pendidikan Tinggi'
            ],
            [
                'period' => '2017 — 2020',
                'institution' => 'SMA Negeri 3 Bandung',
                'degree' => 'Peminatan Matematika dan Ilmu Pengetahuan Alam (MIPA)',
                'gpa' => 'Nilai Rata-rata Ujian: 94.8',
                'thesis' => 'Fokus: Matematika Diskrit, Fisika Komputasi, dan Algoritma Dasar',
                'description' => 'Membangun fondasi logika pemrograman, kalkulus, dan berpartisipasi aktif dalam pembinaan Olimpiade Sains Nasional (OSN) bidang Informatika.',
                'achievements' => ['Medali Perak Olimpiade Sains Komputer Tingkat Provinsi', 'Ketua Komunitas Pemrograman & Robotika Sekolah'],
                'icon' => 'award',
                'badge' => 'Pendidikan Menengah'
            ]
        ];

        // Data Keahlian (Skills) untuk looping @foreach
        $skillCategories = [
            [
                'category' => 'Backend & Architecture',
                'description' => 'Infrastruktur backend yang kokoh, scalable, dan aman.',
                'icon' => 'server',
                'items' => [
                    ['name' => 'Laravel Framework & PHP 8.5+', 'level' => 96, 'exp' => '5 Tahun', 'highlight' => 'Expert Architecture'],
                    ['name' => 'RESTful API & GraphQL Services', 'level' => 94, 'exp' => '5 Tahun', 'highlight' => 'High Concurrency'],
                    ['name' => 'MySQL, PostgreSQL & Database Indexing', 'level' => 91, 'exp' => '4 Tahun', 'highlight' => 'Query Optimization'],
                    ['name' => 'Redis Caching & Queue Worker System', 'level' => 89, 'exp' => '4 Tahun', 'highlight' => 'Sub-millisecond Latency'],
                ]
            ],
            [
                'category' => 'Frontend & Creative Motion',
                'description' => 'Pengalaman antarmuka futuristik, responsif, dan interaktif.',
                'icon' => 'monitor',
                'items' => [
                    ['name' => 'Tailwind CSS & Design Tokens', 'level' => 95, 'exp' => '4 Tahun', 'highlight' => 'Fluid Responsive Design'],
                    ['name' => 'Blade Template Engine & Component Architecture', 'level' => 95, 'exp' => '5 Tahun', 'highlight' => 'Modular Layouts'],
                    ['name' => 'Modern JavaScript ES6+ & DOM Physics', 'level' => 92, 'exp' => '5 Tahun', 'highlight' => '60 FPS Inertia'],
                    ['name' => 'Glassmorphism, 3D Tilt & Canvas Graphics', 'level' => 90, 'exp' => '3 Tahun', 'highlight' => 'Antigravity Aesthetics'],
                ]
            ],
            [
                'category' => 'DevOps, Cloud & Tooling',
                'description' => 'Ekosistem otomasi, container, dan workflow kolaboratif.',
                'icon' => 'cloud-cog',
                'items' => [
                    ['name' => 'Git, GitHub Actions & CI/CD Pipelines', 'level' => 94, 'exp' => '5 Tahun', 'highlight' => 'Automated Testing'],
                    ['name' => 'Docker & Containerized Microservices', 'level' => 88, 'exp' => '3 Tahun', 'highlight' => 'Isolated Environments'],
                    ['name' => 'Vite, Asset Bundling & Performance Profiling', 'level' => 92, 'exp' => '3 Tahun', 'highlight' => 'Lightning Build'],
                    ['name' => 'Linux Server Management & NGINX', 'level' => 87, 'exp' => '4 Tahun', 'highlight' => 'Security Hardened'],
                ]
            ]
        ];

        // Data Hobi untuk looping @foreach
        $hobbies = [
            [
                'title' => 'Eksperimen Creative Coding & UI Fisika',
                'desc' => 'Mengeksplorasi matematika interaksi, partikel dinamis, efek fluida, dan estetika futuristik seperti Google Antigravity IDE.',
                'icon' => 'compass',
                'accent' => 'from-cyan-500/20 to-blue-500/20',
                'tags' => ['Interactive Math', 'Inertia & Lerp', 'Cybernetic UI']
            ],
            [
                'title' => 'Kontribusi Open Source & Knowledge Sharing',
                'desc' => 'Membangun pustaka kode terbuka, menulis artikel arsitektur sistem, dan membantu para pengembang muda di komunitas.',
                'icon' => 'github',
                'accent' => 'from-purple-500/20 to-indigo-500/20',
                'tags' => ['Open Source', 'Clean Architecture', 'Mentorship']
            ],
            [
                'title' => 'Capture The Flag (CTF) & Cyber Security',
                'desc' => 'Menguji ketahanan aplikasi web melalui simulasi eksploitasi etis, reverse engineering, dan audit kriptografi.',
                'icon' => 'shield-alert',
                'accent' => 'from-rose-500/20 to-purple-500/20',
                'tags' => ['Web Pentesting', 'Cryptography', 'AppSec Defense']
            ],
            [
                'title' => 'Audio Synthesis & Synthwave Sound Design',
                'desc' => 'Merancang trek musik ambient elektronik dan lo-fi synthwave menggunakan synthesizer analog virtual untuk fokus kerja maksimal.',
                'icon' => 'music-2',
                'accent' => 'from-amber-500/20 to-cyan-500/20',
                'tags' => ['Modular Synth', 'Cyber Ambient', 'Focus Flow']
            ]
        ];

        return view('pages.about', [
            'profile' => $profile,
            'personalDetails' => $personalDetails,
            'educations' => $educations,
            'skillCategories' => $skillCategories,
            'hobbies' => $hobbies,
        ]);
    }

    /**
     * Halaman Galeri (Gallery)
     */
    public function gallery()
    {
        $profile = $this->getProfileData();

        // Data Galeri Proyek / Portofolio untuk looping @foreach
        $galleries = [
            [
                'id' => 1,
                'title' => 'Quantum Neural Core Engine',
                'category' => 'AI & Distributed Computing',
                'image' => 'images/gallery/gallery1.jpg',
                'year' => '2026',
                'client' => 'Deep Research Institute',
                'badge' => 'Featured Innovation',
                'description' => 'Infrastruktur pengolahan sinyal data neural berkecepatan tinggi dengan visualisasi multi-dimensi secara real-time. Dilengkapi dengan telemetri throughput mikrodetik dan panel interaksi cerdas.',
                'details' => 'Sistem ini memproses jutaan event analitik secara paralel menggunakan arsitektur message-bus terdesentralisasi, dipadukan dengan visualisasi kursor dinamis yang responsif.',
                'tech_stack' => ['Laravel 13', 'PHP 8.5', 'Tailwind CSS', 'Redis', 'Vite', 'Canvas 2D']
            ],
            [
                'id' => 2,
                'title' => 'Cyber Telemetry Realtime Dashboard',
                'category' => 'Cloud Telemetry & Observability',
                'image' => 'images/gallery/gallery2.jpg',
                'year' => '2025',
                'client' => 'HyperScale Network Corp',
                'badge' => 'High Concurrency',
                'description' => 'Dashboard pemantauan status cluster server global dengan estetika glassmorphism, visualisasi latency heatmaps, dan peringatan degradasi node otomatis.',
                'details' => 'Menyediakan interface terpadu untuk monitoring 10,000+ container aktif dengan visualisasi metrik interaktif, grafik animatif, dan kemampuan drill-down per region.',
                'tech_stack' => ['Laravel', 'PostgreSQL', 'Tailwind CSS', 'Vite', 'Lucide Icons']
            ],
            [
                'id' => 3,
                'title' => 'Antigravity Cloud Mesh Engine',
                'category' => 'Infrastructure & Microservices',
                'image' => 'images/gallery/gallery3.jpg',
                'year' => '2025',
                'client' => 'NextGen Cloud Systems',
                'badge' => 'Cloud Architecture',
                'description' => 'Mesin orkestrasi microservice mandiri (self-healing) dengan mekanisme failover instan, auto-scaling cerdas, dan enkripsi payload end-to-end.',
                'details' => 'Dirancang dengan arsitektur zero-trust, memungkinkan penyebaran aplikasi secara seamless dengan downtime nol detik dan manajemen lisensi terdistribusi.',
                'tech_stack' => ['Laravel Horizon', 'Docker', 'Tailwind CSS', 'Redis Cluster', 'CI/CD']
            ],
            [
                'id' => 4,
                'title' => 'Spatial Interaction & Fluid Physics Lab',
                'category' => 'Experimental UI & Motion Physics',
                'image' => 'images/gallery/gallery4.jpg',
                'year' => '2024',
                'client' => 'Creative Web Studio',
                'badge' => 'Creative Frontend',
                'description' => 'Laboratorium eksperimen web masa depan yang menggabungkan inersia kursor gravitasi, parallax multi-dimensi, dan interaksi 3D tilt tanpa library berat.',
                'details' => 'Menggunakan matematika interpolasi halus (lerp) dan perspective rendering untuk menciptakan interaksi antarmuka yang terasa memiliki massa dan momentum.',
                'tech_stack' => ['JavaScript ES6+', 'CSS Transform 3D', 'Tailwind CSS', 'RequestAnimationFrame']
            ],
            [
                'id' => 5,
                'title' => 'Autonomous Sentinel Security Protocol',
                'category' => 'Cyber Security & Biometric Grid',
                'image' => 'images/gallery/gallery5.jpg',
                'year' => '2024',
                'client' => 'Defense & Data Governance',
                'badge' => 'Zero-Trust Protocol',
                'description' => 'Protokol keamanan berlapis dengan verifikasi kredensial terdesentralisasi, audit trail tamper-evident, dan sistem deteksi intrusi berbasis kecerdasan buatan.',
                'details' => 'Mengamankan transaksi data finansial antar entitas dengan enkripsi asimetris kurva eliptik dan manajemen sesi berbasis token berwaktu hidup dinamis.',
                'tech_stack' => ['Laravel Sanctum', 'PHP Crypto', 'Tailwind CSS', 'PostgreSQL', 'REST API']
            ],
            [
                'id' => 6,
                'title' => 'Immersive Developer Workspace IDE',
                'category' => 'Productivity & Next-Gen Developer UX',
                'image' => 'images/gallery/gallery6.jpg',
                'year' => '2026',
                'client' => 'Future Developer Experience',
                'badge' => 'Antigravity Inspired',
                'description' => 'Konsep lingkungan pengembangan kode masa depan dengan navigasi prediktif, tema kontras tinggi nan nyaman, serta integrasi visual feedback yang dinamis.',
                'details' => 'Terinspirasi langsung oleh filosofi Google Antigravity IDE untuk menghadirkan pengalaman ngoding yang menyenangkan, estetis, dan sangat ergonomis.',
                'tech_stack' => ['Laravel Blade', 'Tailwind CSS', 'Vite', 'Lucide Icons', 'Event Bus']
            ],
        ];

        return view('pages.gallery', [
            'profile' => $profile,
            'galleries' => $galleries,
        ]);
    }
}
