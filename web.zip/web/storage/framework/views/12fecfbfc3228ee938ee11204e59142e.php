<?php $__env->startSection('title', 'Galeri Portofolio & Proyek Futuristik — ' . $profile['name']); ?>

<?php $__env->startSection('content'); ?>
<div class="relative py-12 sm:py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">

    <div class="max-w-7xl mx-auto space-y-16 sm:space-y-24">

        <!-- ========================================================================= -->
        <!-- GALLERY HEADER & SHOWCASE DESCRIPTION                                     -->
        <!-- ========================================================================= -->
        <section class="text-center max-w-3xl mx-auto space-y-4 reveal-on-scroll">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
                <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
                DIGITAL SHOWCASE // INTERACTIVE GALLERY
            </div>
            
            <h1 class="text-4xl sm:text-6xl font-display font-extrabold text-white tracking-tight">
                Galeri Karya & Proyek
            </h1>

            <p class="text-slate-400 text-base sm:text-lg leading-relaxed">
                Koleksi visual sistem rekayasa perangkat lunak, antarmuka modern, dan arsitektur terdistribusi. Klik pada gambar untuk membuka tampilan interaktif lightbox beresolusi penuh.
            </p>

            <div class="pt-2 flex flex-wrap items-center justify-center gap-2 text-xs font-mono text-slate-400">
                <span class="px-3 py-1 rounded-full bg-white/[0.04] border border-white/[0.08]">
                    Total Karya: <strong class="text-cyan-400"><?php echo e(count($galleries)); ?> Item</strong>
                </span>
                <span class="px-3 py-1 rounded-full bg-white/[0.04] border border-white/[0.08]">
                    Controller Loop: <strong class="text-purple-300">Blade @foreach</strong>
                </span>
                <span class="px-3 py-1 rounded-full bg-white/[0.04] border border-white/[0.08]">
                    Modal Engine: <strong class="text-emerald-400">Integrated Lightbox</strong>
                </span>
            </div>
        </section>

        <!-- ========================================================================= -->
        <!-- RESPONSIVE GRID GALLERY (LOOPING @foreach DARI CONTROLLER)                -->
        <!-- ========================================================================= -->
        <section class="relative">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10">
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="reveal-on-scroll delay-<?php echo e((($index % 3) + 1) * 150); ?> group relative rounded-3xl overflow-hidden bg-dark-900 border border-white/[0.08] hover:border-cyan-400/50 backdrop-blur-xl shadow-lg transition-all duration-500 tilt-card cursor-pointer"
                             data-tilt-max="10"
                             data-gallery-item
                             data-index="<?php echo e($index); ?>"
                             data-id="<?php echo e($item['id']); ?>"
                             data-title="<?php echo e($item['title']); ?>"
                             data-category="<?php echo e($item['category']); ?>"
                             data-image="<?php echo e(asset($item['image'])); ?>"
                             data-year="<?php echo e($item['year']); ?>"
                             data-client="<?php echo e($item['client']); ?>"
                             data-description="<?php echo e($item['description']); ?>"
                             data-details="<?php echo e($item['details']); ?>"
                             data-tech="<?php echo e(json_encode($item['tech_stack'])); ?>">
                        
                        <!-- Image Container with Hover Zoom & Glowing Sheen -->
                        <div class="relative w-full aspect-[4/3] overflow-hidden bg-dark-950">
                            <img src="<?php echo e(asset($item['image'])); ?>" 
                                 alt="<?php echo e($item['title']); ?>" 
                                 loading="lazy"
                                 class="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110">
                            
                            <!-- Ambient Vignette & Gradient Overlay -->
                            <div class="absolute inset-0 bg-gradient-to-t from-dark-950 via-dark-950/40 to-transparent opacity-80 group-hover:opacity-40 transition-opacity duration-300"></div>

                            <!-- Top Floating Badge -->
                            <div class="absolute top-4 left-4 right-4 flex items-center justify-between">
                                <span class="px-3 py-1 rounded-full text-[11px] font-mono font-medium bg-dark-950/80 backdrop-blur-md text-cyan-300 border border-cyan-500/30 shadow-md">
                                    <?php echo e($item['badge']); ?>

                                </span>
                                <span class="px-2.5 py-1 rounded-full text-[10px] font-mono bg-dark-950/80 backdrop-blur-md text-slate-300 border border-white/[0.1]">
                                    <?php echo e($item['year']); ?>

                                </span>
                            </div>

                            <!-- Center Magnifier Hover Icon -->
                            <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 scale-75 group-hover:scale-100 pointer-events-none">
                                <div class="w-14 h-14 rounded-full bg-cyan-500/30 border border-cyan-400/80 backdrop-blur-md flex items-center justify-center text-cyan-300 shadow-[0_0_25px_rgba(6,182,212,0.6)]">
                                    <i data-lucide="maximize-2" class="w-6 h-6"></i>
                                </div>
                            </div>
                        </div>

                        <!-- Card Content Information -->
                        <div class="p-6 sm:p-7 space-y-3">
                            <span class="text-xs font-mono uppercase tracking-wider text-cyan-400 block font-medium">
                                <?php echo e($item['category']); ?>

                            </span>

                            <h3 class="text-xl font-display font-bold text-white group-hover:text-cyan-300 transition-colors">
                                <?php echo e($item['title']); ?>

                            </h3>

                            <p class="text-sm text-slate-400 line-clamp-2 leading-relaxed">
                                <?php echo e($item['description']); ?>

                            </p>

                            <!-- Tech Stack Badges (Mini loop) -->
                            <div class="pt-3 flex flex-wrap gap-1.5 border-t border-white/[0.06]">
                                <?php $__currentLoopData = array_slice($item['tech_stack'], 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="px-2.5 py-0.5 rounded text-[10px] font-mono bg-white/[0.03] text-slate-300 border border-white/[0.06]">
                                        <?php echo e($tech); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($item['tech_stack']) > 3): ?>
                                    <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                                        +<?php echo e(count($item['tech_stack']) - 3); ?> more
                                    </span>
                                <?php endif; ?>
                            </div>

                            <!-- Trigger Footer -->
                            <div class="pt-2 flex items-center justify-between text-xs font-mono text-cyan-400/80 group-hover:text-cyan-300">
                                <span class="flex items-center gap-1.5">
                                    <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                    Lihat Detail & Foto Penuh
                                </span>
                                <i data-lucide="arrow-right" class="w-4 h-4 transition-transform group-hover:translate-x-1"></i>
                            </div>
                        </div>

                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <!-- ========================================================================= -->
        <!-- BOTTOM NAVIGATION CTA                                                     -->
        <!-- ========================================================================= -->
        <section class="reveal-on-scroll text-center py-8">
            <div class="inline-flex flex-wrap items-center justify-center gap-4 p-4 rounded-2xl bg-dark-850/60 border border-white/[0.08] backdrop-blur-md">
                <span class="text-xs sm:text-sm font-mono text-slate-300">Ingin melihat profil pemilik karya ini?</span>
                <a href="<?php echo e(route('about')); ?>" 
                   class="px-5 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 shadow-md transition-all magnetic-btn flex items-center gap-1.5">
                    <i data-lucide="user" class="w-3.5 h-3.5"></i>
                    Buka Halaman Profil
                </a>
            </div>
        </section>

    </div>

    <!-- ========================================================================= -->
    <!-- INTERACTIVE LIGHTBOX MODAL COMPONENT (FULL DETAILS & NAV)                 -->
    <!-- ========================================================================= -->
    <div id="gallery-lightbox" 
         class="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 lg:p-10 opacity-0 pointer-events-none transition-all duration-300"
         role="dialog"
         aria-modal="true"
         aria-labelledby="lightbox-title">
        
        <!-- Backdrop Blur Overlay (Click to close) -->
        <div id="lightbox-backdrop" class="absolute inset-0 bg-[#030612]/90 backdrop-blur-2xl transition-opacity duration-300"></div>

        <!-- Modal Dialog Card Window -->
        <div id="lightbox-content" 
             class="relative z-10 w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-dark-850 via-dark-900 to-dark-950 border border-cyan-500/30 shadow-[0_25px_80px_rgba(0,0,0,0.8)] scale-95 transition-transform duration-300 flex flex-col">
            
            <!-- Modal Header Controls -->
            <div class="sticky top-0 z-20 flex items-center justify-between p-4 sm:p-6 bg-dark-900/95 backdrop-blur-xl border-b border-white/[0.08]">
                <div class="flex items-center gap-3">
                    <span id="lightbox-index-badge" class="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                        Item 1 / 6
                    </span>
                    <span id="lightbox-category" class="text-xs font-mono uppercase tracking-widest text-slate-400 hidden sm:inline">
                        Kategori Proyek
                    </span>
                </div>

                <!-- Navigation & Close Buttons -->
                <div class="flex items-center gap-2">
                    <button id="lightbox-prev-btn" 
                            class="p-2.5 rounded-xl bg-dark-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 border border-white/[0.08] transition-all magnetic-btn"
                            aria-label="Foto Sebelumnya (Tombol Panah Kiri)">
                        <i data-lucide="chevron-left" class="w-5 h-5"></i>
                    </button>
                    <button id="lightbox-next-btn" 
                            class="p-2.5 rounded-xl bg-dark-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 border border-white/[0.08] transition-all magnetic-btn"
                            aria-label="Foto Selanjutnya (Tombol Panah Kanan)">
                        <i data-lucide="chevron-right" class="w-5 h-5"></i>
                    </button>
                    <button id="lightbox-close-btn" 
                            class="p-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-all magnetic-btn ml-2"
                            aria-label="Tutup Lightbox (Escape)">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
            </div>

            <!-- Modal Body (Two-Column Layout: Large Image + Detailed Info) -->
            <div class="p-4 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                <!-- Left: Full Display Image -->
                <div class="lg:col-span-7 rounded-2xl overflow-hidden border border-white/[0.1] bg-dark-950 shadow-2xl relative group">
                    <img id="lightbox-img" 
                         src="" 
                         alt="" 
                         class="w-full h-auto max-h-[550px] object-contain mx-auto transition-transform duration-500">
                    <div class="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-dark-950/80 backdrop-blur-md text-[10px] font-mono text-slate-400 border border-white/[0.1]">
                        Antigravity High-Res Node
                    </div>
                </div>

                <!-- Right: Detailed Spec Sheet & Tech Stack -->
                <div class="lg:col-span-5 space-y-6">
                    <div>
                        <h2 id="lightbox-title" class="text-2xl sm:text-3xl font-display font-extrabold text-white leading-tight">
                            Judul Proyek
                        </h2>
                        <div class="flex items-center gap-3 mt-2 font-mono text-xs text-slate-400">
                            <span>Tahun: <strong id="lightbox-year" class="text-cyan-400 font-semibold">2026</strong></span>
                            <span>•</span>
                            <span>Klien: <strong id="lightbox-client" class="text-slate-200 font-semibold">Deep Research</strong></span>
                        </div>
                    </div>

                    <!-- Short Description -->
                    <div class="space-y-2">
                        <h4 class="text-xs font-mono uppercase tracking-widest text-cyan-400">
                            Ringkasan Proyek
                        </h4>
                        <p id="lightbox-description" class="text-sm text-slate-300 leading-relaxed">
                            Deskripsi proyek lengkap.
                        </p>
                    </div>

                    <!-- Detailed Technical Architecture -->
                    <div class="space-y-2 p-4 rounded-xl bg-dark-950/70 border border-white/[0.06]">
                        <h4 class="text-xs font-mono uppercase tracking-widest text-purple-400 flex items-center gap-1.5">
                            <i data-lucide="cpu" class="w-3.5 h-3.5"></i>
                            Spesifikasi & Implementasi
                        </h4>
                        <p id="lightbox-details" class="text-xs text-slate-400 leading-relaxed font-sans">
                            Detail teknis arsitektur.
                        </p>
                    </div>

                    <!-- Tech Stack Badges -->
                    <div class="space-y-2">
                        <h4 class="text-xs font-mono uppercase tracking-widest text-cyan-400">
                            Teknologi & Tools
                        </h4>
                        <div id="lightbox-tech-stack" class="flex flex-wrap gap-2">
                            <!-- Populated dynamically via gallery.js -->
                        </div>
                    </div>

                    <!-- Action Link / Toast Trigger -->
                    <div class="pt-2">
                        <button id="lightbox-copy-link-btn" 
                                class="w-full py-3 rounded-xl text-xs font-semibold uppercase tracking-wider text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 hover:border-cyan-400 transition-all flex items-center justify-center gap-2 magnetic-btn">
                            <i data-lucide="share-2" class="w-3.5 h-3.5"></i>
                            <span>Bagikan URL Informasi Karya Ini</span>
                        </button>
                    </div>
                </div>

            </div>

        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dikap\OneDrive\Dokumen\web\resources\views/pages/gallery.blade.php ENDPATH**/ ?>