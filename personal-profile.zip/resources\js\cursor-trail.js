import Alpine from 'alpinejs';

Alpine.data('cursorTrail', () => {
    let root;
    let elements = [];
    let particles = [];

    return {
        enabled: false,
        active: false,
        frame: null,
        lastFrameTime: 0,
        mouseX: 0,
        mouseY: 0,

        init() {
            root = this.$root;
            elements = Array.from(root.querySelectorAll('.cursor-trail-particle'));
            particles = elements.map(() => ({ x: 0, y: 0 }));
            this.enabled = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
        },

        move(event) {
            if (!this.enabled || elements.length === 0) {
                return;
            }

            this.mouseX = event.clientX;
            this.mouseY = event.clientY;

            if (!this.active) {
                this.active = true;
                root.classList.add('is-active');

                particles.forEach((particle) => {
                    particle.x = this.mouseX;
                    particle.y = this.mouseY;
                });
            }

            if (this.frame === null) {
                this.frame = requestAnimationFrame((time) => this.animate(time));
            }
        },

        hide() {
            this.active = false;
            this.lastFrameTime = 0;
            root?.classList.remove('is-active');

            if (this.frame !== null) {
                cancelAnimationFrame(this.frame);
                this.frame = null;
            }
        },

        animate(time) {
            const elapsed = this.lastFrameTime ? Math.min(time - this.lastFrameTime, 32) : 16.67;
            this.lastFrameTime = time;
            let isMoving = false;

            particles.forEach((particle, index) => {
                const target = index === 0 ? { x: this.mouseX, y: this.mouseY } : particles[index - 1];
                const easing = 1 - Math.exp(-elapsed / (index === 0 ? 72 : 92));
                const deltaX = target.x - particle.x;
                const deltaY = target.y - particle.y;

                particle.x += deltaX * easing;
                particle.y += deltaY * easing;
                elements[index].style.transform =
                    `translate3d(${particle.x}px, ${particle.y}px, 0) scale(var(--trail-scale))`;

                if (Math.abs(deltaX) > 0.15 || Math.abs(deltaY) > 0.15) {
                    isMoving = true;
                }
            });

            if (isMoving && this.active) {
                this.frame = requestAnimationFrame((nextTime) => this.animate(nextTime));
            } else {
                this.frame = null;
                this.lastFrameTime = 0;
            }
        },
    };
});
