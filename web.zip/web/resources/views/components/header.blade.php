<header id="main-header" class="sticky top-0 z-40 w-full transition-all duration-300 backdrop-blur-xl bg-[#040711]/75 border-b border-white/[0.08] dark:border-white/[0.06]">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">

            <!-- Futuristic Brand Identity / Logo -->
            <a href="{{ route('welcome') }}" class="group flex items-center gap-3 magnetic-btn" aria-label="Beranda">
                <div class="relative flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500/20 via-blue-500/15 to-purple-600/20 border border-cyan-400/30 group-hover:border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.15)] group-hover:shadow-[0_0_25px_rgba(6,182,212,0.4)] transition-all duration-300">
                    <span class="font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 text-lg tracking-wider">AP</span>
                    <!-- Glowing Corner Accent -->
                    <span class="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
                </div>
                <div class="flex flex-col">
                    <div class="flex items-center gap-2">
                        <span class="font-display font-bold text-base sm:text-lg text-slate-100 tracking-tight group-hover:text-cyan-400 transition-colors duration-300">
                            ANDIKA<span class="text-cyan-400">.</span>DEV
                        </span>
                        <span class="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                            v2.6
                        </span>
                    </div>
                    <span class="text-[11px] font-mono text-slate-400 tracking-widest uppercase">
                        Future Architect
                    </span>
                </div>
            </a>

            <!-- Desktop Futuristic Navigation Links -->
            <nav class="hidden md:flex items-center p-1.5 rounded-full bg-dark-850/80 border border-white/[0.08] backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
                <!-- Welcome Page Link -->
                <a href="{{ route('welcome') }}" 
                   class="relative px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 {{ request()->routeIs('welcome') ? 'text-cyan-300 shadow-[0_0_20px_rgba(6,182,212,0.25)]' : 'text-slate-300 hover:text-white' }} group">
                    @if(request()->routeIs('welcome'))
                        <span class="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 border border-cyan-400/40" aria-hidden="true"></span>
                    @endif
                    <span class="relative z-10 flex items-center gap-2">
                        <i data-lucide="sparkles" class="w-4 h-4 {{ request()->routeIs('welcome') ? 'text-cyan-400 animate-pulse' : 'text-slate-400 group-hover:text-cyan-400' }}"></i>
                        Welcome
                    </span>
                </a>

                <!-- About Me Link -->
                <a href="{{ route('about') }}" 
                   class="relative px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 {{ request()->routeIs('about') ? 'text-cyan-300 shadow-[0_0_20px_rgba(6,182,212,0.25)]' : 'text-slate-300 hover:text-white' }} group">
                    @if(request()->routeIs('about'))
                        <span class="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 border border-cyan-400/40" aria-hidden="true"></span>
                    @endif
                    <span class="relative z-10 flex items-center gap-2">
                        <i data-lucide="user" class="w-4 h-4 {{ request()->routeIs('about') ? 'text-cyan-400 animate-pulse' : 'text-slate-400 group-hover:text-cyan-400' }}"></i>
                        About Me
                    </span>
                </a>

                <!-- Gallery Link -->
                <a href="{{ route('gallery') }}" 
                   class="relative px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 {{ request()->routeIs('gallery') ? 'text-cyan-300 shadow-[0_0_20px_rgba(6,182,212,0.25)]' : 'text-slate-300 hover:text-white' }} group">
                    @if(request()->routeIs('gallery'))
                        <span class="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 border border-cyan-400/40" aria-hidden="true"></span>
                    @endif
                    <span class="relative z-10 flex items-center gap-2">
                        <i data-lucide="grid" class="w-4 h-4 {{ request()->routeIs('gallery') ? 'text-cyan-400 animate-pulse' : 'text-slate-400 group-hover:text-cyan-400' }}"></i>
                        Gallery
                    </span>
                </a>
            </nav>

            <!-- Right Header Controls: Theme Toggle & CTA -->
            <div class="flex items-center gap-3">

                <!-- Dark / Light Mode Switch Button -->
                <button id="theme-toggle" 
                        class="p-2.5 rounded-xl bg-dark-850/80 hover:bg-dark-750 text-slate-300 hover:text-cyan-400 border border-white/[0.08] transition-all duration-300 magnetic-btn shadow-sm"
                        aria-label="Ganti Mode Tema">
                    <i data-lucide="sun" id="theme-icon-light" class="w-5 h-5 hidden"></i>
                    <i data-lucide="moon" id="theme-icon-dark" class="w-5 h-5 block"></i>
                </button>

                <!-- Quick Connect Button -->
                <a href="{{ route('about') }}#contact" 
                   class="hidden lg:inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider text-slate-900 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-400 hover:from-cyan-300 hover:to-blue-300 shadow-[0_0_20px_rgba(6,182,212,0.35)] hover:shadow-[0_0_30px_rgba(6,182,212,0.6)] transition-all duration-300 magnetic-btn">
                    <i data-lucide="send" class="w-3.5 h-3.5"></i>
                    Hubungi Saya
                </a>

                <!-- Mobile Hamburger Toggle Button -->
                <button id="mobile-menu-btn" 
                        class="md:hidden p-2.5 rounded-xl bg-dark-850/80 text-slate-300 hover:text-cyan-400 border border-white/[0.08] transition-colors focus:outline-none"
                        aria-label="Buka Menu Navigasi"
                        aria-expanded="false">
                    <i data-lucide="menu" id="menu-icon-open" class="w-6 h-6 block"></i>
                    <i data-lucide="x" id="menu-icon-close" class="w-6 h-6 hidden"></i>
                </button>
            </div>

        </div>
    </div>

    <!-- Mobile Drawer Navigation -->
    <div id="mobile-menu" 
         class="md:hidden hidden border-b border-white/[0.08] bg-dark-900/95 backdrop-blur-2xl transition-all duration-300">
        <div class="px-4 pt-3 pb-6 space-y-2">
            <a href="{{ route('welcome') }}" 
               class="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium {{ request()->routeIs('welcome') ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30' : 'text-slate-300 hover:bg-white/5' }} transition-all">
                <i data-lucide="sparkles" class="w-5 h-5 text-cyan-400"></i>
                Welcome
            </a>
            <a href="{{ route('about') }}" 
               class="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium {{ request()->routeIs('about') ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30' : 'text-slate-300 hover:bg-white/5' }} transition-all">
                <i data-lucide="user" class="w-5 h-5 text-cyan-400"></i>
                About Me (Data Diri)
            </a>
            <a href="{{ route('gallery') }}" 
               class="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium {{ request()->routeIs('gallery') ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30' : 'text-slate-300 hover:bg-white/5' }} transition-all">
                <i data-lucide="grid" class="w-5 h-5 text-cyan-400"></i>
                Gallery (Koleksi Proyek)
            </a>
            <div class="pt-3 border-t border-white/[0.08]">
                <a href="{{ route('about') }}#contact" 
                   class="flex items-center justify-center gap-2 w-full py-3 rounded-xl text-sm font-semibold uppercase tracking-wider text-slate-900 bg-gradient-to-r from-cyan-400 to-blue-400 shadow-[0_0_20px_rgba(6,182,212,0.35)]">
                    <i data-lucide="send" class="w-4 h-4"></i>
                    Hubungi Saya
                </a>
            </div>
        </div>
    </div>
</header>
