<?php

namespace App\Http\Controllers;

use DateTimeImmutable;

class ProfileController extends Controller
{
    public function welcome()
    {
        $profile = [
            'full_name' => 'Dikaptra',
            'first_name' => 'Dikaptra',
            'title' => 'Creative Developer & Digital Storyteller',
            'tagline' => 'Membuat pengalaman digital yang hidup, elegan, dan berkesan.',
            'location' => 'Denpasar, Bali',
            'email' => 'dikapttraaa@gmail.com',
            'website' => 'https://github.com/dikapttraaa',
        ];

        return view('pages.welcome', compact('profile'));
    }

    public function about()
    {
        $birthDate = new DateTimeImmutable('2007-01-31');
        $today = new DateTimeImmutable('today');

        $profile = [
            'full_name' => 'Dikaptra',
            'birth_place' => 'Denpasar',
            'birth_date' => '31 Januari 2007',
            'age' => $birthDate->diff($today)->y,
            'gender' => 'Laki-laki',
            'address' => 'Jl. Danau Beratan GG VIII/II, No 6',
            'education' => 'S1 Informatika',
            'hobbies' => ['Membaca', 'Fotografi', 'Traveling', 'Ngoding', 'Bermain musik'],
            'skills' => ['PHP', 'Laravel', 'Tailwind CSS', 'JavaScript', 'UI/UX', 'Vite', 'REST API'],
            'vision' => 'Menjadi developer yang membawa ide kreatif menjadi produk digital yang berdampak.',
            'description' => 'Saya adalah seorang pengembang web yang tertarik pada pengalaman visual, produk digital, dan storytelling melalui interface yang rapi serta interaktif.',
        ];

        $infos = [
            ['label' => 'Nama lengkap', 'value' => $profile['full_name']],
            ['label' => 'Tempat, tanggal lahir', 'value' => $profile['birth_place'].', '.$profile['birth_date']],
            ['label' => 'Umur', 'value' => $profile['age'].' Tahun'],
            ['label' => 'Jenis kelamin', 'value' => $profile['gender']],
            ['label' => 'Alamat', 'value' => $profile['address']],
            ['label' => 'Pendidikan', 'value' => $profile['education']],
        ];

        $education = [
            ['period' => '2019 — 2021', 'title' => 'SMP Negeri 9 Denpasar', 'detail' => 'Membangun fondasi logika, kreativitas, dan disiplin belajar.'],
            ['period' => '2021 — 2024', 'title' => 'SMA negeri 6 Denpasar', 'detail' => 'Mempelajari pemrograman, desain, dan teknologi web modern.'],
            ['period' => '2025 — 2029', 'title' => 'S1 Informatika', 'detail' => 'Mengembangkan kemampuan analisis, problem solving, dan pengembangan produk digital.'],
        ];

        return view('pages.about', compact('profile', 'infos', 'education'));
    }

    public function gallery()
    {
        $profile = ['full_name' => 'Dikaptra'];

        return view('pages.gallery', compact('profile'));
    }
}
