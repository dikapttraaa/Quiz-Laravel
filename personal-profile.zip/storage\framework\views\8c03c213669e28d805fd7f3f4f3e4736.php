<header class="sticky top-0 z-40 w-full border-b border-white/10 bg-slate-950/60 backdrop-blur-xl">
    <nav class="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <a href="<?php echo e(route('welcome')); ?>" class="flex items-center gap-3">
            <div class="flex h-10 w-10 items-center justify-center rounded-xl border border-cyan-400/40 bg-cyan-500/10 text-lg font-bold text-cyan-300 shadow-glow">
                A
            </div>
            <div>
                <p class="text-sm uppercase tracking-[0.24em] text-slate-400">Profile</p>
                <p class="text-lg font-semibold text-white">Dikaptra</p>
            </div>
        </a>

        <div class="hidden items-center gap-3 md:flex">
            <a href="<?php echo e(route('welcome')); ?>" data-nav-link class="rounded-full border border-transparent px-4 py-2 text-sm font-medium text-slate-200 transition hover:border-cyan-400/30 hover:bg-cyan-500/5 hover:text-cyan-200">
                Welcome
            </a>
            <a href="<?php echo e(route('about')); ?>" data-nav-link class="rounded-full border border-transparent px-4 py-2 text-sm font-medium text-slate-200 transition hover:border-cyan-400/30 hover:bg-cyan-500/5 hover:text-cyan-200">
                Profil Saya
            </a>
            <a href="<?php echo e(route('gallery')); ?>" data-nav-link class="rounded-full border border-transparent px-4 py-2 text-sm font-medium text-slate-200 transition hover:border-cyan-400/30 hover:bg-cyan-500/5 hover:text-cyan-200">
                Galeri
            </a>
        </div>

        <button type="button" data-nav-toggle aria-expanded="false" aria-controls="site-navigation" aria-label="Toggle navigation" class="inline-flex items-center justify-center rounded-full border border-white/10 bg-white/5 p-2 text-slate-100 transition hover:border-cyan-400/30 hover:text-cyan-300 md:hidden">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 7h16M4 12h16M4 17h16" />
            </svg>
        </button>
    </nav>

    <div id="site-navigation" data-nav-menu aria-hidden="true" class="nav-menu border-t border-white/10 bg-slate-950/95 md:hidden">
        <div class="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-4">
            <a href="<?php echo e(route('welcome')); ?>" data-nav-link class="rounded-xl px-3 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/5 hover:text-cyan-200">Welcome</a>
            <a href="<?php echo e(route('about')); ?>" data-nav-link class="rounded-xl px-3 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/5 hover:text-cyan-200">About Me</a>
            <a href="<?php echo e(route('gallery')); ?>" data-nav-link class="rounded-xl px-3 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/5 hover:text-cyan-200">Gallery</a>
        </div>
    </div>
</header>
<?php /**PATH C:\Users\LENOVO\Downloads\Quiz-Laravel\personal-profile\resources\views/components/header.blade.php ENDPATH**/ ?>