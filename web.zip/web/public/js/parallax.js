/**
 * ============================================================================
 * INTERACTIVE PARALLAX & 3D TILT PHYSICS
 * Inspired by Google Antigravity IDE
 * ============================================================================
 * Mengatur pergerakan multi-kedalaman elemen ambient, objek melayang,
 * dan card tilt 3D interaktif yang merespons posisi mouse pengguna.
 */

(function () {
    'use strict';

    const isFinePointer = window.matchMedia('(pointer: fine) and (hover: hover)').matches;
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!isFinePointer || prefersReducedMotion) return;

    // 1. Ambient Background & Float Elements Parallax
    const ambientElements = document.querySelectorAll('.parallax-ambient');
    const floatElements = document.querySelectorAll('.parallax-float');

    let mouseNormX = 0; // Rentang -1 sampai +1
    let mouseNormY = 0; // Rentang -1 sampai +1
    let currentX = 0;
    let currentY = 0;

    window.addEventListener('mousemove', (e) => {
        const halfW = window.innerWidth / 2;
        const halfH = window.innerHeight / 2;
        mouseNormX = (e.clientX - halfW) / halfW;
        mouseNormY = (e.clientY - halfH) / halfH;
    }, { passive: true });

    function updateParallax() {
        // Lerp pergerakan mouse global
        currentX += (mouseNormX - currentX) * 0.08;
        currentY += (mouseNormY - currentY) * 0.08;

        // Gerakkan ambient orbs
        ambientElements.forEach((el) => {
            const depth = parseFloat(el.getAttribute('data-parallax-depth')) || 0.05;
            const moveX = currentX * depth * 80;
            const moveY = currentY * depth * 80;
            el.style.transform = `translate3d(${moveX}px, ${moveY}px, 0)`;
        });

        // Gerakkan floating badges
        floatElements.forEach((el) => {
            const speed = parseFloat(el.getAttribute('data-float-speed')) || 1;
            const moveX = currentX * speed * 22;
            const moveY = currentY * speed * 18;
            el.style.transform = `translate3d(${moveX}px, ${moveY}px, 0)`;
        });

        requestAnimationFrame(updateParallax);
    }

    requestAnimationFrame(updateParallax);

    // 2. Interactive 3D Card Tilt with Perspective & Glare
    function init3DTiltCards() {
        const tiltCards = document.querySelectorAll('.tilt-card');

        tiltCards.forEach((card) => {
            // Pasang glare overlay jika belum ada
            if (!card.querySelector('.tilt-glare') && card.getAttribute('data-tilt-glare') === 'true') {
                const glare = document.createElement('div');
                glare.className = 'tilt-glare';
                card.appendChild(glare);
            }

            const maxTilt = parseFloat(card.getAttribute('data-tilt-max')) || 10;

            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                const centerX = rect.width / 2;
                const centerY = rect.height / 2;

                const rotateX = -((y - centerY) / centerY) * maxTilt;
                const rotateY = ((x - centerX) / centerX) * maxTilt;

                card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.02, 1.02, 1.02)`;

                // Update posisi pantulan cahaya glare
                const glareX = (x / rect.width) * 100;
                const glareY = (y / rect.height) * 100;
                card.style.setProperty('--mouse-x', `${glareX}%`);
                card.style.setProperty('--mouse-y', `${glareY}%`);
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
            });
        });
    }

    document.addEventListener('DOMContentLoaded', init3DTiltCards);

    // Pasang untuk elemen yang muncul dinamis
    const mutationObserver = new MutationObserver(() => {
        init3DTiltCards();
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });

})();
