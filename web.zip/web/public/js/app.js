/**
 * ============================================================================
 * MAIN APPLICATION ORCHESTRATOR
 * Personal Profile Interactive Futuristic Portfolio
 * ============================================================================
 */

(function () {
    'use strict';

    // 1. Dark Mode / Light Mode Controller with LocalStorage Persistence
    function initThemeMode() {
        const themeToggleBtn = document.getElementById('theme-toggle');
        const iconLight = document.getElementById('theme-icon-light');
        const iconDark = document.getElementById('theme-icon-dark');
        const html = document.documentElement;

        // Cek preferensi tersimpan atau preferensi sistem operasi
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'light') {
            html.classList.remove('dark');
            updateThemeIcons(false);
        } else {
            html.classList.add('dark');
            updateThemeIcons(true);
        }

        if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', () => {
                const isDark = html.classList.toggle('dark');
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
                updateThemeIcons(isDark);

                if (window.showToast) {
                    window.showToast(isDark ? 'Mode Gelap Cyber Aktif' : 'Mode Terang Aktif');
                }
            });
        }

        function updateThemeIcons(isDark) {
            if (iconLight && iconDark) {
                if (isDark) {
                    iconLight.classList.add('hidden');
                    iconDark.classList.remove('hidden');
                } else {
                    iconLight.classList.remove('hidden');
                    iconDark.classList.add('hidden');
                }
            }
        }
    }

    // 2. Mobile Responsive Navigation Drawer Controller
    function initMobileMenu() {
        const menuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        const iconOpen = document.getElementById('menu-icon-open');
        const iconClose = document.getElementById('menu-icon-close');

        if (!menuBtn || !mobileMenu) return;

        menuBtn.addEventListener('click', () => {
            const isExpanded = menuBtn.getAttribute('aria-expanded') === 'true';
            menuBtn.setAttribute('aria-expanded', !isExpanded);

            if (isExpanded) {
                mobileMenu.classList.add('hidden');
                iconOpen.classList.remove('hidden');
                iconClose.classList.add('hidden');
            } else {
                mobileMenu.classList.remove('hidden');
                iconOpen.classList.add('hidden');
                iconClose.classList.remove('hidden');
            }
        });
    }

    // 3. Global Toast Notification System
    window.showToast = function (message, duration = 3000) {
        const toast = document.getElementById('toast-notification');
        const toastMsg = document.getElementById('toast-message');

        if (!toast || !toastMsg) return;

        toastMsg.textContent = message;
        toast.classList.remove('opacity-0', 'pointer-events-none', 'translate-y-6');
        toast.classList.add('opacity-100', 'translate-y-0');

        clearTimeout(window._toastTimeout);
        window._toastTimeout = setTimeout(() => {
            toast.classList.add('opacity-0', 'pointer-events-none', 'translate-y-6');
            toast.classList.remove('opacity-100', 'translate-y-0');
        }, duration);
    };

    // 4. Copy Email Handler
    function initCopyEmail() {
        const copyEmailBtn = document.getElementById('copy-email-btn');
        if (!copyEmailBtn) return;

        copyEmailBtn.addEventListener('click', () => {
            const email = copyEmailBtn.getAttribute('data-email') || 'andika.pratama@antigravity.dev';
            navigator.clipboard.writeText(email).then(() => {
                window.showToast(`Email ${email} berhasil disalin ke clipboard!`);
            }).catch(() => {
                window.showToast(`Email: ${email}`);
            });
        });
    }

    // 5. Sticky Header Glassmorphism Scroll Elevation
    function initHeaderScroll() {
        const header = document.getElementById('main-header');
        if (!header) return;

        window.addEventListener('scroll', () => {
            if (window.scrollY > 20) {
                header.classList.add('shadow-lg', 'bg-[#040711]/90', 'border-cyan-500/20');
            } else {
                header.classList.remove('shadow-lg', 'bg-[#040711]/90', 'border-cyan-500/20');
            }
        }, { passive: true });
    }

    // Initialize all components on DOM Ready
    document.addEventListener('DOMContentLoaded', () => {
        initThemeMode();
        initMobileMenu();
        initCopyEmail();
        initHeaderScroll();

        if (window.lucide) {
            window.lucide.createIcons();
        }
    });

})();
