<!DOCTYPE html>
<html lang="id" class="dark scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Andika Pratama — Personal Profile Interactive Futuristic')</title>
    
    <!-- Meta SEO & Theme -->
    <meta name="description" content="Personal Profile modern, futuristik, dan interaktif terinspirasi oleh Google Antigravity IDE. Dibangun dengan Laravel, Tailwind CSS, dan JavaScript murni.">
    <meta name="theme-color" content="#030712">

    <!-- Google Fonts: Plus Jakarta Sans, Space Grotesk, JetBrains Mono -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Tailwind CSS Script CDN (Memastikan website langsung bisa dijalankan tanpa build npm) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        dark: {
                            950: '#030712',
                            900: '#070b15',
                            850: '#0c1322',
                            800: '#111a2e',
                            750: '#17223b',
                            700: '#1e2d4d'
                        },
                        cyber: {
                            blue: '#3b82f6',
                            cyan: '#06b6d4',
                            purple: '#8b5cf6',
                            violet: '#a855f7',
                            neon: '#38bdf8',
                            pink: '#ec4899',
                            emerald: '#10b981'
                        }
                    },
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
                        display: ['"Space Grotesk"', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    },
                    animation: {
                        'pulse-glow': 'pulseGlow 5s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'float-slow': 'floatSlow 7s ease-in-out infinite',
                        'float-delayed': 'floatSlow 9s ease-in-out 3s infinite',
                        'spin-slow': 'spin 24s linear infinite',
                        'spin-reverse': 'spinReverse 30s linear infinite',
                        'grid-move': 'gridMove 20s linear infinite',
                    },
                    keyframes: {
                        pulseGlow: {
                            '0%, 100%': { opacity: '0.4', transform: 'scale(1)' },
                            '50%': { opacity: '0.75', transform: 'scale(1.12)' }
                        },
                        floatSlow: {
                            '0%, 100%': { transform: 'translateY(0px) rotate(0deg)' },
                            '50%': { transform: 'translateY(-16px) rotate(2deg)' }
                        },
                        spinReverse: {
                            '0%': { transform: 'rotate(360deg)' },
                            '100%': { transform: 'rotate(0deg)' }
                        },
                        gridMove: {
                            '0%': { backgroundPosition: '0 0' },
                            '100%': { backgroundPosition: '40px 40px' }
                        }
                    }
                }
            }
        }
    </script>

    <!-- Lucide Icons Library -->
    <script src="https://unpkg.com/lucide@latest"></script>

    <!-- App Stylesheet (Glassmorphism, Neon Shadows, Tilt, Cursor & Animations) -->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">

    @if (file_exists(public_path('build/manifest.json')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @endif

    @stack('styles')
</head>
<body class="bg-[#040711] text-slate-100 font-sans antialiased overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200 transition-colors duration-500">

    <!-- Interactive Custom Cursor Follower System (Disabled on Touch) -->
    <div id="cursor-dot" class="cursor-dot pointer-events-none" aria-hidden="true"></div>
    <div id="cursor-glow" class="cursor-glow pointer-events-none" aria-hidden="true"></div>

    <!-- Futuristic Ambient Background Canvas & Parallax Light Layers -->
    <div class="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
        <!-- Interactive Cyber Grid -->
        <div class="cyber-grid absolute inset-0 opacity-[0.14] dark:opacity-[0.18]"></div>

        <!-- Ambient Floating Glowing Orbs (Reacts smoothly to Parallax) -->
        <div class="parallax-ambient absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-cyan-600/20 via-blue-600/15 to-transparent blur-[120px] animate-pulse-glow" data-parallax-depth="0.08"></div>
        <div class="parallax-ambient absolute top-1/3 -right-40 w-[650px] h-[650px] rounded-full bg-gradient-to-br from-purple-600/20 via-indigo-600/15 to-transparent blur-[130px] animate-pulse-glow" data-parallax-depth="-0.06"></div>
        <div class="parallax-ambient absolute -bottom-40 left-1/3 w-[700px] h-[700px] rounded-full bg-gradient-to-t from-blue-700/15 via-cyan-600/10 to-transparent blur-[140px] animate-pulse-glow" data-parallax-depth="0.05"></div>

        <!-- Subtle Scanlines / Antigravity Atmosphere -->
        <div class="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(59,130,246,0.15),rgba(255,255,255,0))]"></div>
    </div>

    <!-- Main Application Wrapper -->
    <div class="relative z-10 flex flex-col min-h-screen">

        <!-- Global Header Component -->
        @include('components.header')

        <!-- Page Specific Dynamic Content -->
        <main class="flex-grow">
            @yield('content')
        </main>

        <!-- Global Footer Component -->
        @include('components.footer')

    </div>

    <!-- Back to Top Floating Button (with Magnetic Effect) -->
    <button id="back-to-top" 
            class="fixed bottom-7 right-7 z-40 p-3.5 rounded-full bg-dark-850/90 hover:bg-dark-750 text-cyan-400 border border-cyan-500/30 shadow-[0_0_20px_rgba(6,182,212,0.25)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] transition-all duration-300 opacity-0 pointer-events-none translate-y-4 magnetic-btn group" 
            aria-label="Kembali ke atas">
        <i data-lucide="chevron-up" class="w-5 h-5 transition-transform duration-300 group-hover:-translate-y-1"></i>
    </button>

    <!-- Global Toast Notification Feedback -->
    <div id="toast-notification" 
         class="fixed bottom-7 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3 rounded-xl bg-dark-900/90 text-slate-100 border border-cyan-500/30 backdrop-blur-xl shadow-2xl transition-all duration-300 opacity-0 pointer-events-none translate-y-6">
        <div class="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping"></div>
        <span id="toast-message" class="text-sm font-medium">Notifikasi Sistem</span>
    </div>

    <!-- Core Modular JavaScript Scripts -->
    <script src="{{ asset('js/cursor-follower.js') }}"></script>
    <script src="{{ asset('js/parallax.js') }}"></script>
    <script src="{{ asset('js/magnetic-button.js') }}"></script>
    <script src="{{ asset('js/scroll-animation.js') }}"></script>
    <script src="{{ asset('js/gallery.js') }}"></script>
    <script src="{{ asset('js/app.js') }}"></script>

    <!-- Initialize Lucide Icons -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            if (window.lucide) {
                window.lucide.createIcons();
            }
        });
    </script>

    @stack('scripts')
</body>
</html>
