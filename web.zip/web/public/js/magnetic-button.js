/**
 * ============================================================================
 * MAGNETIC BUTTON PHYSICS INTERACTION
 * Inspired by Google Antigravity IDE
 * ============================================================================
 * Memberikan sensasi gaya tarik magnetik pada tombol saat kursor mendekat,
 * dengan transisi pegas (spring return) saat kursor menjauh.
 */

(function () {
    'use strict';

    const isFinePointer = window.matchMedia('(pointer: fine) and (hover: hover)').matches;
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!isFinePointer || prefersReducedMotion) return;

    function initMagneticButtons() {
        const magneticButtons = document.querySelectorAll('.magnetic-btn');

        magneticButtons.forEach((btn) => {
            // Hindari double-binding
            if (btn.dataset.magneticInit === 'true') return;
            btn.dataset.magneticInit = 'true';

            const strength = parseFloat(btn.getAttribute('data-magnetic-strength')) || 0.28;

            btn.addEventListener('mousemove', (e) => {
                const rect = btn.getBoundingClientRect();
                const btnCenterX = rect.left + rect.width / 2;
                const btnCenterY = rect.top + rect.height / 2;

                const deltaX = (e.clientX - btnCenterX) * strength;
                const deltaY = (e.clientY - btnCenterY) * strength;

                btn.style.transform = `translate3d(${deltaX.toFixed(2)}px, ${deltaY.toFixed(2)}px, 0)`;
            });

            btn.addEventListener('mouseleave', () => {
                btn.style.transform = 'translate3d(0px, 0px, 0px)';
            });
        });
    }

    document.addEventListener('DOMContentLoaded', initMagneticButtons);

    const observer = new MutationObserver(() => {
        initMagneticButtons();
    });
    observer.observe(document.body, { childList: true, subtree: true });

})();
