/**
 * ============================================================================
 * SCROLL REVEAL ANIMATIONS & BACK TO TOP OBSERVER
 * ============================================================================
 * Menggunakan Intersection Observer API yang dioptimalkan untuk performa tinggi,
 * memicu animasi fade-in dan slide-up secara bertahap (staggered).
 */

(function () {
    'use strict';

    function initScrollReveal() {
        const revealElements = document.querySelectorAll('.reveal-on-scroll');

        if (!('IntersectionObserver' in window)) {
            // Fallback untuk browser lama
            revealElements.forEach((el) => el.classList.add('is-revealed'));
            return;
        }

        const observerOptions = {
            root: null,
            rootMargin: '0px 0px -60px 0px',
            threshold: 0.12
        };

        const observer = new IntersectionObserver((entries, obs) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-revealed');
                    obs.unobserve(entry.target); // Hanya animasikan sekali
                }
            });
        }, observerOptions);

        revealElements.forEach((el) => {
            observer.observe(el);
        });
    }

    // Back to Top Button Controller
    function initBackToTop() {
        const backToTopBtn = document.getElementById('back-to-top');
        if (!backToTopBtn) return;

        window.addEventListener('scroll', () => {
            if (window.scrollY > 350) {
                backToTopBtn.classList.remove('opacity-0', 'pointer-events-none', 'translate-y-4');
                backToTopBtn.classList.add('opacity-100', 'translate-y-0');
            } else {
                backToTopBtn.classList.add('opacity-0', 'pointer-events-none', 'translate-y-4');
                backToTopBtn.classList.remove('opacity-100', 'translate-y-0');
            }
        }, { passive: true });

        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        initScrollReveal();
        initBackToTop();
    });

})();
