<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ProfileController::class, 'welcome'])->name('welcome');
Route::get('/about', [ProfileController::class, 'about'])->name('about');
Route::get('/gallery', [ProfileController::class, 'gallery'])->name('gallery');
