const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const hasFinePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

if (!prefersReducedMotion && hasFinePointer) {
    const cursor = document.createElement('div');
    cursor.className = 'cursor-follower';
    document.body.appendChild(cursor);

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let currentX = mouseX;
    let currentY = mouseY;
    let animationFrame = null;
    let hideTimeout = null;

    const hideCursor = () => {
        window.clearTimeout(hideTimeout);
        hideTimeout = null;
        cursor.style.opacity = '0';
        document.body.classList.remove('pointer-active');
    };

    window.addEventListener('pointermove', (event) => {
        mouseX = event.clientX;
        mouseY = event.clientY;
        cursor.style.opacity = '1';
        document.body.classList.add('pointer-active');
        window.clearTimeout(hideTimeout);
        hideTimeout = window.setTimeout(hideCursor, 900);

        if (animationFrame === null) {
            animationFrame = requestAnimationFrame(animateCursor);
        }
    });

    window.addEventListener('pointerleave', hideCursor);
    window.addEventListener('blur', hideCursor);
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            hideCursor();
        }
    });

    const animateCursor = () => {
        currentX += (mouseX - currentX) * 0.15;
        currentY += (mouseY - currentY) * 0.15;
        cursor.style.transform = `translate(${currentX}px, ${currentY}px) translate(-50%, -50%)`;
        document.documentElement.style.setProperty('--pointer-x', `${currentX}px`);
        document.documentElement.style.setProperty('--pointer-y', `${currentY}px`);
        if (Math.abs(mouseX - currentX) > 0.1 || Math.abs(mouseY - currentY) > 0.1) {
            animationFrame = requestAnimationFrame(animateCursor);
        } else {
            currentX = mouseX;
            currentY = mouseY;
            animationFrame = null;
        }
    };

    const interactiveItems = document.querySelectorAll('a, button, .card-tilt, .gallery-item, .magnetic');
    interactiveItems.forEach((item) => {
        item.addEventListener('mouseenter', () => cursor.classList.add('cursor-hover'));
        item.addEventListener('mouseleave', () => cursor.classList.remove('cursor-hover'));
    });
}
