<nav class="bottom-navigation" aria-label="Navigasi utama">
    <div class="bottom-navigation__dock">
        <a
            href="<?php echo e(route('welcome')); ?>"
            class="bottom-navigation__link"
            <?php if(request()->routeIs('welcome')): ?> aria-current="page" <?php endif; ?>
        >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="m3.75 10.5 8.25-6.75 8.25 6.75v9a.75.75 0 0 1-.75.75h-5.25v-6h-4.5v6H4.5a.75.75 0 0 1-.75-.75v-9Z" />
            </svg>
            <span>Welcome</span>
        </a>

        <a
            href="<?php echo e(route('about')); ?>"
            class="bottom-navigation__link"
            <?php if(request()->routeIs('about')): ?> aria-current="page" <?php endif; ?>
        >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6.75a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.5 20.25a7.5 7.5 0 0 1 15 0v.75h-15v-.75Z" />
            </svg>
            <span>Profil Saya</span>
        </a>

        <a
            href="<?php echo e(route('gallery')); ?>"
            class="bottom-navigation__link"
            <?php if(request()->routeIs('gallery')): ?> aria-current="page" <?php endif; ?>
        >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 5.25A1.5 1.5 0 0 1 5.25 3.75h13.5a1.5 1.5 0 0 1 1.5 1.5v13.5a1.5 1.5 0 0 1-1.5 1.5H5.25a1.5 1.5 0 0 1-1.5-1.5V5.25Z" />
                <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 16.5 4.1-4.1a1.5 1.5 0 0 1 2.12 0l1.03 1.03 2.78-2.78a1.5 1.5 0 0 1 2.12 0l3.6 3.6M8.25 8.25h.008v.008H8.25V8.25Z" />
            </svg>
            <span>Gallery</span>
        </a>
    </div>
</nav>
<?php /**PATH C:\Users\LENOVO\Downloads\Quiz-Laravel\personal-profile\resources\views\components\bottom-navigation.blade.php ENDPATH**/ ?>