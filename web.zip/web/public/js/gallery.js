/**
 * ============================================================================
 * INTERACTIVE GALLERY LIGHTBOX & MODAL SYSTEM
 * ============================================================================
 * Mengatur pembukaan gambar resolusi penuh, navigasi next/prev, keyboard controls,
 * dan rendering dinamis informasi spesifikasi karya.
 */

(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', () => {
        const lightbox = document.getElementById('gallery-lightbox');
        if (!lightbox) return;

        const backdrop = document.getElementById('lightbox-backdrop');
        const content = document.getElementById('lightbox-content');
        const closeBtn = document.getElementById('lightbox-close-btn');
        const prevBtn = document.getElementById('lightbox-prev-btn');
        const nextBtn = document.getElementById('lightbox-next-btn');

        const imgEl = document.getElementById('lightbox-img');
        const titleEl = document.getElementById('lightbox-title');
        const categoryEl = document.getElementById('lightbox-category');
        const badgeIndexEl = document.getElementById('lightbox-index-badge');
        const yearEl = document.getElementById('lightbox-year');
        const clientEl = document.getElementById('lightbox-client');
        const descriptionEl = document.getElementById('lightbox-description');
        const detailsEl = document.getElementById('lightbox-details');
        const techStackEl = document.getElementById('lightbox-tech-stack');
        const copyLinkBtn = document.getElementById('lightbox-copy-link-btn');

        const galleryCards = Array.from(document.querySelectorAll('[data-gallery-item]'));
        if (galleryCards.length === 0) return;

        let currentIndex = 0;
        let isOpen = false;

        // Buka Lightbox dengan index tertentu
        function openLightbox(index) {
            currentIndex = (index + galleryCards.length) % galleryCards.length;
            const card = galleryCards[currentIndex];

            const title = card.getAttribute('data-title');
            const category = card.getAttribute('data-category');
            const image = card.getAttribute('data-image');
            const year = card.getAttribute('data-year');
            const client = card.getAttribute('data-client');
            const description = card.getAttribute('data-description');
            const details = card.getAttribute('data-details');
            const tech = JSON.parse(card.getAttribute('data-tech') || '[]');

            // Set konten modal
            imgEl.src = image;
            imgEl.alt = title;
            titleEl.textContent = title;
            categoryEl.textContent = category;
            badgeIndexEl.textContent = `Item ${currentIndex + 1} / ${galleryCards.length}`;
            yearEl.textContent = year;
            clientEl.textContent = client;
            descriptionEl.textContent = description;
            detailsEl.textContent = details;

            // Render Tech Stack Badges
            techStackEl.innerHTML = '';
            tech.forEach((t) => {
                const span = document.createElement('span');
                span.className = 'px-2.5 py-1 rounded-lg text-xs font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20';
                span.textContent = t;
                techStackEl.appendChild(span);
            });

            // Tampilkan lightbox
            lightbox.classList.remove('opacity-0', 'pointer-events-none');
            lightbox.classList.add('opacity-100');
            content.classList.remove('scale-95');
            content.classList.add('scale-100');
            document.body.classList.add('overflow-hidden');

            isOpen = true;

            // Refresh lucide icons jika ada icon baru
            if (window.lucide) {
                window.lucide.createIcons();
            }
        }

        // Tutup Lightbox
        function closeLightbox() {
            lightbox.classList.add('opacity-0', 'pointer-events-none');
            lightbox.classList.remove('opacity-100');
            content.classList.add('scale-95');
            content.classList.remove('scale-100');
            document.body.classList.remove('overflow-hidden');
            isOpen = false;
        }

        function showNext() {
            openLightbox(currentIndex + 1);
        }

        function showPrev() {
            openLightbox(currentIndex - 1);
        }

        // Pasang event listener pada setiap card galeri
        galleryCards.forEach((card, idx) => {
            card.addEventListener('click', () => {
                openLightbox(idx);
            });
        });

        // Kontrol Tombol Modal
        closeBtn.addEventListener('click', closeLightbox);
        backdrop.addEventListener('click', closeLightbox);
        nextBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showNext();
        });
        prevBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showPrev();
        });

        // Keyboard Navigation (Escape, ArrowLeft, ArrowRight)
        window.addEventListener('keydown', (e) => {
            if (!isOpen) return;

            if (e.key === 'Escape') {
                closeLightbox();
            } else if (e.key === 'ArrowRight') {
                showNext();
            } else if (e.key === 'ArrowLeft') {
                showPrev();
            }
        });

        // Salin URL Informasi Proyek
        if (copyLinkBtn) {
            copyLinkBtn.addEventListener('click', () => {
                const currentCard = galleryCards[currentIndex];
                const title = currentCard.getAttribute('data-title');
                const url = window.location.href.split('#')[0] + `#gallery-${currentIndex + 1}`;
                
                navigator.clipboard.writeText(url).then(() => {
                    if (window.showToast) {
                        window.showToast(`URL untuk "${title}" berhasil disalin!`);
                    }
                }).catch(() => {
                    if (window.showToast) {
                        window.showToast(`Info karya: ${title}`);
                    }
                });
            });
        }
    });

})();
