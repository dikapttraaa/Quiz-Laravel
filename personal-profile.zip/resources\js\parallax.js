const parallaxLayers = document.querySelectorAll('[data-parallax]');

if (window.matchMedia('(hover: hover) and (pointer: fine)').matches
    && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    let pointerX = 0;
    let pointerY = 0;
    let animationFrame = 0;

    window.addEventListener('pointermove', (event) => {
        pointerX = event.clientX;
        pointerY = event.clientY;

        if (animationFrame) return;

        animationFrame = window.requestAnimationFrame(() => {
            const x = (pointerX / window.innerWidth - 0.5) * 16;
            const y = (pointerY / window.innerHeight - 0.5) * 16;

            parallaxLayers.forEach((layer) => {
                const speed = Number(layer.dataset.parallax || 1);
                layer.style.translate = `${x * speed}px ${y * speed}px`;
            });
            animationFrame = 0;
        });
    });
}
