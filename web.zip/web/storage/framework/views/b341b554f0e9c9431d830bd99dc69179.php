<footer class="relative z-20 mt-auto border-t border-white/[0.08] bg-[#030610]/90 backdrop-blur-xl">
    <!-- Ambient Glow Line on Top -->
    <div class="h-[1px] w-full bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
            
            <!-- Col 1: Brand & Philosophy -->
            <div class="md:col-span-2 space-y-4">
                <div class="flex items-center gap-3">
                    <div class="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-600/20 border border-cyan-400/40 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                        <span class="font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 text-base">AP</span>
                    </div>
                    <span class="font-display font-bold text-lg text-slate-100">
                        <?php echo e($profile['name'] ?? 'Andika Pratama'); ?>

                    </span>
                </div>
                <p class="text-sm text-slate-400 leading-relaxed max-w-md">
                    Personal Profile & Portfolio interaktif futuristik. Dirancang dengan rekayasa clean code Laravel Blade, kecepatan Tailwind CSS, dan visual interaktif dinamis yang terinspirasi oleh filosofi eksperimental Antigravity.
                </p>
                <div class="flex items-center gap-2 pt-2">
                    <span class="relative flex h-2.5 w-2.5">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                    <span class="text-xs font-mono text-emerald-400">
                        System Status: All Nodes Operational (Online)
                    </span>
                </div>
            </div>

            <!-- Col 2: Navigation Links -->
            <div>
                <h4 class="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-4 flex items-center gap-2">
                    <i data-lucide="compass" class="w-3.5 h-3.5"></i>
                    Navigasi Cepat
                </h4>
                <ul class="space-y-2.5 text-sm">
                    <li>
                        <a href="<?php echo e(route('welcome')); ?>" class="text-slate-400 hover:text-cyan-300 transition-colors flex items-center gap-2 group">
                            <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 transition-colors"></i>
                            Welcome Page
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('about')); ?>" class="text-slate-400 hover:text-cyan-300 transition-colors flex items-center gap-2 group">
                            <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 transition-colors"></i>
                            Data Diri / About Me
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('gallery')); ?>" class="text-slate-400 hover:text-cyan-300 transition-colors flex items-center gap-2 group">
                            <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 transition-colors"></i>
                            Galeri Portofolio
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('about')); ?>#contact" class="text-slate-400 hover:text-cyan-300 transition-colors flex items-center gap-2 group">
                            <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 transition-colors"></i>
                            Kontak & Kolaborasi
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Col 3: Social Networks & Connect -->
            <div>
                <h4 class="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-4 flex items-center gap-2">
                    <i data-lucide="share-2" class="w-3.5 h-3.5"></i>
                    Jejaring Sosial
                </h4>
                <div class="flex flex-wrap gap-2.5">
                    <?php
                        $socials = $profile['socials'] ?? [
                            ['name' => 'GitHub', 'icon' => 'github', 'url' => 'https://github.com'],
                            ['name' => 'LinkedIn', 'icon' => 'linkedin', 'url' => 'https://linkedin.com'],
                            ['name' => 'Instagram', 'icon' => 'instagram', 'url' => 'https://instagram.com'],
                            ['name' => 'Twitter/X', 'icon' => 'twitter', 'url' => 'https://twitter.com'],
                            ['name' => 'Email', 'icon' => 'mail', 'url' => 'mailto:andika.pratama@antigravity.dev'],
                        ];
                    ?>

                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($soc['url']); ?>" 
                           target="_blank" 
                           rel="noopener noreferrer" 
                           class="p-2.5 rounded-xl bg-dark-850 hover:bg-cyan-500/10 text-slate-400 hover:text-cyan-400 border border-white/[0.08] hover:border-cyan-500/40 shadow-sm transition-all duration-300 magnetic-btn group"
                           title="<?php echo e($soc['name']); ?>"
                           aria-label="<?php echo e($soc['name']); ?>">
                            <i data-lucide="<?php echo e($soc['icon']); ?>" class="w-4 h-4 transition-transform group-hover:scale-110"></i>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-4 p-3 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                    <span class="text-[11px] font-mono text-slate-400 block mb-1">Direct Transmission:</span>
                    <a href="mailto:<?php echo e($profile['email'] ?? 'andika.pratama@antigravity.dev'); ?>" class="text-xs font-mono text-cyan-400 hover:underline break-all">
                        <?php echo e($profile['email'] ?? 'andika.pratama@antigravity.dev'); ?>

                    </a>
                </div>
            </div>

        </div>

        <!-- Bottom Bar: Copyright & Credits -->
        <div class="pt-8 border-t border-white/[0.06] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400 font-mono">
            <div class="flex items-center gap-1.5 text-center sm:text-left">
                <span>&copy; <?php echo e(date('Y')); ?></span>
                <span class="font-semibold text-slate-200"><?php echo e($profile['name'] ?? 'Andika Pratama'); ?></span>.
                <span class="hidden sm:inline">Hak Cipta Dilindungi.</span>
            </div>
            <div class="flex items-center gap-2">
                <span>Made with <span class="text-rose-500 animate-pulse">❤️</span> and futuristic passion</span>
                <span class="text-slate-600">•</span>
                <span class="text-cyan-400">Antigravity Inspired</span>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\dikap\OneDrive\Dokumen\web\resources\views/components/footer.blade.php ENDPATH**/ ?>